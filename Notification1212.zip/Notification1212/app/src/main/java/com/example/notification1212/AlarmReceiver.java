package com.example.notification1212;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.util.Log;

public class AlarmReceiver extends BroadcastReceiver {

    public NotificationManager notificationManager;
    public Notification notification;
    public final static int NOTIFICATION_ID = 1;

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.
        Intent notifyIntent = new Intent(context,MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context,0, notifyIntent, PendingIntent.FLAG_MUTABLE);
        new Thread(){
            @Override
            public void run() {
                notificationManager = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
                notification = new Notification.Builder(context)
                        .setSmallIcon(R.drawable.ic_launcher_foreground)
                        .setContentTitle("訊息")
                        .setContentText("記得記帳喔!")
                        .setContentIntent(pendingIntent)
                        .build();
                notificationManager.notify(NOTIFICATION_ID, notification);
                super.run();
            }
        }.start();





        throw new UnsupportedOperationException("Not yet implemented");
    }
    public void broadcastNotify(Context context, PendingIntent pendingIntent){

    }
}