package com.my.notebook.myapplication.ui.main;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Trace;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.PieChart;
import com.my.notebook.myapplication.MyData;
import com.my.notebook.myapplication.MyUser;
import com.my.notebook.myapplication.R;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class AccountPage extends Fragment
        implements FragmentInterface
{
    private final AccountPage THIS= this ;
    private final MyData _data ;

    private PieChart _pieChart;

    private Button btnLogin,btnSignup,btnLogout;

    private View _root,_v,_s ;

    private Handler handler = new Handler();


    public AccountPage(MyData data )
    {
        super();
        _data = data ;

    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {

        final View root = _root =inflater.inflate(R.layout.fragment_main_account_page, container, false);

        btnLogin = _root.findViewById(R.id.btnLogin);
        btnSignup = _root.findViewById(R.id.btnSignup);
        btnLogout = _root.findViewById(R.id.btnLogout);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Thread t = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                View v = _v = inflater.inflate(R.layout.view_login, container, false);

                                new AlertDialog.Builder(getContext())
                                        .setView(v)
                                        .setPositiveButton("登入", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                EditText et ;
                                                et =  _v.findViewById( R.id.edittext_user );
                                                String user = et.getText().toString();

                                                et =  _v.findViewById( R.id.edittext_pass );
                                                String pass = et.getText().toString();

                                                _data.signUser( _onFirebaseCallback , user , pass , null );
                                            }
                                        })
                                        .setOnDismissListener(new DialogInterface.OnDismissListener() {
                                            @Override
                                            public void onDismiss(DialogInterface dialogInterface) {
                                                _v = null;
                                            }
                                        })
                                        .show();
                            }
                        });
                    }
                });
                t.start();
                try {
                    Thread.sleep(500);
                    t.interrupt();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Thread t = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                View v = _v = inflater.inflate(R.layout.view_sign, container, false);

                                new AlertDialog.Builder(getContext())
                                        .setView(v)
                                        .setPositiveButton("登入", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                EditText et ;
                                                et =  _v.findViewById( R.id.edittext_user );
                                                String user = et.getText().toString();

                                                et =  _v.findViewById( R.id.edittext_pass );
                                                String pass = et.getText().toString();

                                                MyUser User = _data.getUser();

                                                et = _v.findViewById( R.id.my_name );
                                                String name = et.getText().toString();
                                                User.name = name;

                                                et = _v.findViewById( R.id.my_profession );
                                                String pro = et.getText().toString();
                                                User.profession = pro;

                                                String salary = "0";
                                                User.salary = 0;

                                                et = _v.findViewById( R.id.my_budget );
                                                String budget = et.getText().toString();
                                                User.budget = Integer.parseInt(budget);

                                                Log.d("sub","upd");
                                                _data.flaskUserUpdate(name,pro,salary,budget,root);
                                                _data.createUser( _onFirebaseCallback , User , user , pass , null );
//                                                Log.d("sub","upd");
//                                                _data.setUser( _onFirebaseCallback , User );
                                            }
                                        })
                                        .setOnDismissListener(new DialogInterface.OnDismissListener() {
                                            @Override
                                            public void onDismiss(DialogInterface dialogInterface) {
                                                _v = null;
                                            }
                                        })
                                        .show();
                            }
                        });
                    }
                });
                t.start();
                try {
                    Thread.sleep(500);
                    t.interrupt();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                _data.logoutUser(_onFirebaseCallback, 0);
            }
        });


     //   upDate();
        _data.getUserData( this._onFirebaseCallback );

        return root ;

    }

    @Override
    public void upDate()
    {
        if(_data.isLogin()) {
            //flask
            //創建OkHttpClient
            OkHttpClient client = new OkHttpClient().newBuilder().build();
            //放入要POST的參數
            FormBody formBody = new FormBody.Builder()
                    .add("uid", _data.getUID())
                    .build();
            //建立request
            Request request = new Request.Builder()
                    .post(formBody)
                    .url(_data._url + "/getInfo")//flask server網址
                    .build();
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    //建立call
                    Call call = client.newCall(request);
                    try {
                        //取得回傳資訊
                        Response response = call.execute();
                        String responseData = response.body().string();
                        //資訊字串分割
                        String[] data = responseData.split(",");
                        //轉換資料型態
                        String textUser = data[0];
                        String textName = data[1];
                        String textPro = data[2];
                        String textbudget = String.format("$ %s", data[3]);
                        String textMoney = String.format("\n本月總收入　：$ %s\n本月總支出　：$ %s\n本月願望目標：$ %s", data[4], data[5], data[6]);
                        int targetMoney = Integer.valueOf(data[7]);
                        Boolean status = Boolean.parseBoolean(data[8]);

                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                TextView tv;
                                Button btnLogin,btnLogout;
                                btnLogin = _root.findViewById(R.id.btnLogin);
                                btnSignup = _root.findViewById(R.id.btnSignup);
                                btnLogout = _root.findViewById(R.id.btnLogout);
                                if (_data.isLogin()) {
//                                    _root.findViewById(R.id.layout_login).setVisibility(View.GONE);
//                                    _root.findViewById(R.id.layout_my_page).setVisibility(View.VISIBLE);
                                    btnLogin.setVisibility(View.GONE);
                                    btnSignup.setVisibility(View.GONE);
                                    btnLogout.setVisibility(View.VISIBLE);
                                } else {
//                                    _root.findViewById(R.id.layout_login).setVisibility(View.VISIBLE);
//                                    _root.findViewById(R.id.layout_my_page).setVisibility(View.GONE);
                                    btnLogin.setVisibility(View.VISIBLE);
                                    btnSignup.setVisibility(View.VISIBLE);
                                    btnLogout.setVisibility(View.GONE);
                                }
                                //

                                _root.findViewById(R.id.button_sign).setOnClickListener(_onSignClickListener);
                                _root.findViewById(R.id.button_create).setOnClickListener(_onCreateClickListener);

                                String textTarget = "";
                                TextView tvTarget = _root.findViewById(R.id.my_yymm2);
                                //元件指向與資訊擺放
                                setText(R.id.my_username, textUser);
                                setText(R.id.my_name, textName);
                                setText(R.id.my_profession, textPro);
                                setText(R.id.my_budget, textbudget);
                                setText(R.id.my_yymm, textMoney);
                                //判斷是否有執行中目標
                                if(status == true) {
                                    //判斷是否達成願望目標
                                    if (targetMoney > 0) {
                                        textTarget = String.format("\n目標未達成\n還需省下$%s", data[7]);
                                        setText(R.id.my_yymm2, textTarget);
                                        tvTarget.setTextColor(Color.BLUE);
                                    } else {
                                        textTarget = String.format("\n目標已達成");
                                        setText(R.id.my_yymm2, textTarget);
                                        tvTarget.setTextColor(Color.RED);
                                    }
                                }
                                else {
                                    textTarget = String.format("\n無執行中的目標");
                                    setText(R.id.my_yymm2, textTarget);
                                }
                            }
                        });

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
            t.start();
            try {
                Thread.sleep(500);
                t.interrupt();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        else{
            TextView tv ;
            btnLogin = _root.findViewById(R.id.btnLogin);
            btnSignup = _root.findViewById(R.id.btnSignup);
            btnLogout = _root.findViewById(R.id.btnLogout);
            if (_data.isLogin()) {
//                _root.findViewById(R.id.layout_login).setVisibility(View.GONE);
//                _root.findViewById(R.id.layout_my_page).setVisibility(View.VISIBLE);
                btnLogin.setVisibility(View.GONE);
                btnSignup.setVisibility(View.GONE);
                btnLogout.setVisibility(View.VISIBLE);
            } else {
//                _root.findViewById(R.id.layout_login).setVisibility(View.VISIBLE);
//                _root.findViewById(R.id.layout_my_page).setVisibility(View.GONE);
                btnLogin.setVisibility(View.VISIBLE);
                btnSignup.setVisibility(View.VISIBLE);
                btnLogout.setVisibility(View.GONE);
            }
            //
            _root.findViewById(R.id.button_sign ).setOnClickListener( _onSignClickListener );
            _root.findViewById(R.id.button_create).setOnClickListener(_onCreateClickListener);



            String textTarget = String.format("\n請先登入");
            String textMoney = String.format("\n本月總收入　：$ %s\n本月總支出　：$ %s\n本月願望目標：$ %s", 0, 0, 0);
            //元件指向與資訊擺放
            setText(R.id.my_username, "未登入");
            setText(R.id.my_name, "訪客");
            setText(R.id.my_profession, "未知");
            setText(R.id.my_budget, "$ 0");
            setText(R.id.my_yymm, textMoney);
            setText(R.id.my_yymm2, textTarget);
        }
    }
    //
    private void setText( int id , Object text )
    {

        try
        {
            TextView tv;
            tv = _root.findViewById( id );
            tv.setText( text.toString() );
        }catch ( Exception e )
        {
            e.printStackTrace();
        }

    }

    //

    //
    private final MyData.CallCloudListener _onFirebaseCallback = new MyData.CallCloudListener()
    {

        @Override
        public void onReturn( boolean isOk, Object inData )
        {
            upDate();
        }
    };

    // 註冊
    private final View.OnClickListener _onCreateClickListener = new View.OnClickListener()
    {
        @Override
        public void onClick(View v) {
            EditText et ;
            et =  _root.findViewById( R.id.edittext_user );
            String user = et.getText().toString();

            et =  _root.findViewById( R.id.edittext_pass );
            String pass = et.getText().toString();

//            _data.createUser( _onFirebaseCallback , user , pass , null );
        }
    };


    // 登入
    private final View.OnClickListener _onSignClickListener = new View.OnClickListener()
    {
        @Override
        public void onClick(View v)
        {
            EditText et ;
            et =  _root.findViewById( R.id.edittext_user );
            String user = et.getText().toString();

            et =  _root.findViewById( R.id.edittext_pass );
            String pass = et.getText().toString();

            _data.signUser( _onFirebaseCallback , user , pass , null );
        }
    };


    // 登出
    private final View.OnClickListener _onLogoutClickListener = new View.OnClickListener()
    {
        @Override
        public void onClick(View v) {

            _data.logoutUser( _onFirebaseCallback , null );
        }
    };

    private String get( int id , String value )
    {
        try
        {
            TextView tv = _root.findViewById( id );
            value = tv.getText().toString();
        }catch ( Exception e )
        {
            e.printStackTrace();
        }
        return value ;
    }
    private int get( int id , int value )
    {
        try
        {
            TextView tv = _root.findViewById( id );
            value = Integer.parseInt( tv.getText().toString() );
        }catch ( Exception e )
        {
            e.printStackTrace();
        }
        return value ;
    }

    // 更新
    private final View.OnClickListener _onUpdateClickListener = new View.OnClickListener()
    {
        @Override
        public void onClick(View v) {

            MyUser user = _data.getUser();
            user.name = get( R.id.my_name , user.name );
            user.budget = get( R.id.my_budget , user.budget );
            user.salary = get( R.id.my_salary , user.salary );
            user.profession = get( R.id.my_profession , user.profession );
            _data.setUser( _onFirebaseCallback , user );
        }
    };


}
