package com.example.test1106;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    private ProgressBar circlepg;
    private Button Quitbtn;
    private Button Completebtn;
    private TextView pgtxt;
    private Button AddTargbtn;
    private TextView TarView;
    //以下是Dialog內的原件
    private Dialog TarDialog;
    private View viewDialog;
    private EditText Target, TarMoney;
    private Button Ok, Cancel;

    private int pg = 0;
    private int TarNum = 0;
    private int budget = 600;

    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        circlepg = (ProgressBar) findViewById(R.id.progress_bar);
        Quitbtn = (Button)findViewById(R.id.QuitButton);
        Completebtn = (Button)findViewById(R.id.CompleteButton);
        pgtxt = (TextView) findViewById(R.id.progress_text);
        AddTargbtn = (Button)findViewById(R.id.AddTarget);
        TarView = (TextView)findViewById(R.id.TarView);



        Quitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        if(TarNum != 0){
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    //要做的事件寫在這裡面
                                }
                            });
                            try{
                                Thread.sleep(200);
                            }catch (InterruptedException e)
                            {
                                e.printStackTrace();
                            }
                        }
                    }
                }).start();
            }
        });

        Completebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        if(TarNum != 0){
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    //要做的事件寫在這裡面
                                }
                            });
                            try{
                                Thread.sleep(200);
                            }catch (InterruptedException e)
                            {
                                e.printStackTrace();
                            }
                        }
                    }
                }).start();
            }
        });

        AddTargbtn.setOnClickListener(new View.OnClickListener() {   //新增目標
            @Override
            public void onClick(View view) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                TarDialog = new Dialog(MainActivity.this);
                                viewDialog = getLayoutInflater().inflate(R.layout.view_add , null);

                                TarDialog.setContentView(viewDialog);
                                Target = viewDialog.findViewById(R.id.Target);
                                TarMoney = viewDialog.findViewById(R.id.TarMoney);
                                Ok = viewDialog.findViewById(R.id.Ok);
                                Cancel = viewDialog.findViewById(R.id.Cancel);

                                TarDialog.show();
                                Ok.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {

                                        TarNum = Integer.parseInt(TarMoney.getText().toString());
                                        pg = budget;
                                        circlepg.setMax(TarNum);
                                        circlepg.setProgress(pg);
                                        pgtxt.setText(budget+"/"+TarNum);
                                        TarView.setText(Target.getText());
                                        TarDialog.dismiss();
                                        TarView.setVisibility(view.VISIBLE);
                                        Quitbtn.setVisibility(view.VISIBLE);
                                        AddTargbtn.setVisibility(view.INVISIBLE);
                                    }
                                });
                                Cancel.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        TarDialog.dismiss();
                                    }
                                });
                            }
                        });
                        try{
                            Thread.sleep(200);
                        }catch (InterruptedException e)
                        {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
    }
}