package com.my.notebook.myapplication.ui.main.result;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.my.notebook.myapplication.MyData;
import com.my.notebook.myapplication.R;

import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class result1 extends Fragment {

    private MyData _data ;

    private String Msg = "";
    private int Img = 0;

    private Handler handler = new Handler();

    public result1( MyData data ) {
        super();
        _data = data;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View v = inflater.inflate(R.layout.fragment_result1, container, false);

        try {
            //創建OkHttpClient
            OkHttpClient client = new OkHttpClient().newBuilder().connectTimeout(500, TimeUnit.MILLISECONDS).build();
            //放入要POST的參數
            FormBody formBody = new FormBody.Builder()
                    .add("uid", _data.getUID())
                    .build();
            //建立request
            Request request = new Request.Builder()
                    .post(formBody)
                    .url(_data._url + "/result1")//flask server網址
                    .build();
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    //建立call
                    Call call = client.newCall(request);
                    try {
                        Response response = call.execute();
                        Boolean responseData = Boolean.parseBoolean(response.body().string());
                        if(responseData == true){
                            Msg = "這個月有省到錢\n恭喜\n請繼續保持";
                            Img = R.drawable.good;
                        }
                        else{
                            Msg = "這個月沒有省到錢\n可惜\n要注意自己的花費哦";
                            Img = R.drawable.bad;
                        }
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                setText(R.id.msg1,Msg,v);
                                setImg(R.id.img1,Img,v);
                            }
                        });

                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            t.start();
            try {
                Thread.sleep(500);
                t.interrupt();
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }catch ( Exception e ){
            e.printStackTrace();
        }

        return v;
    }

    //文字元件指向與資訊擺放
    private void setText( int id , String txt , View view )
    {
        try
        {
            TextView tv;
            tv = view.findViewById( id );
            tv.setText( txt );
        }catch ( Exception e )
        {
            e.printStackTrace();
        }
    }

    //圖片元件指向與資訊擺放
    private void setImg( int id , int img , View view )
    {
        try
        {
            ImageView iv;
            iv = view.findViewById( id );
            iv.setImageResource(img);
        }catch ( Exception e )
        {
            e.printStackTrace();
        }
    }
}