package com.my.notebook.myapplication.ui.main;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.my.notebook.myapplication.MyData;
import com.my.notebook.myapplication.PageAdapter;
import com.my.notebook.myapplication.R;
import com.my.notebook.myapplication.ui.main.result.result1;
import com.my.notebook.myapplication.ui.main.result.result2;
import com.my.notebook.myapplication.ui.main.result.result3;
import com.my.notebook.myapplication.ui.main.result.result4;

import java.util.Calendar;

import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class ResultPage extends Fragment
        implements FragmentInterface
{
    private MyData _data ;
    private View _root ;
    private Calendar cal = Calendar.getInstance();;

    private String[] Msg = new String[4];
    private int[] Img = new int[4];

    private Button btnActive;
    private ConstraintLayout cl;

    ViewPager2 myViewPager2;
    PageAdapter _adapter;

    private Handler handler = new Handler();

    public ResultPage( MyData data ) {
        // Required empty public constructor
        super();
        _data = data;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View v  = _root = inflater.inflate(R.layout.fragment_main_result_page, container, false);
        upDate();
        try {
            //行事曆物件定義
            int dd = cal.get(Calendar.DAY_OF_MONTH);

            myViewPager2 = v.findViewById(R.id.viewPager2);
            btnActive = v.findViewById(R.id.btnActive);
            cl = v.findViewById(R.id.cl_check);
            if(_data.isLogin()) {
                if (dd >= 15) {
                    btnActive.setVisibility(View.VISIBLE);
                    setText(R.id.txtDate, "趕快來結算吧", v);
                } else {
                    setText(R.id.txtDate, "25號還沒到哦\n之後再來吧", v);
                }
            }
            else{
                setText(R.id.txtDate, "請先登入再來", v);
            }

            btnActive.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Thread t = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    myViewPager2.setVisibility(View.VISIBLE);
                                }
                            });
                        }
                    });
                    t.start();
                    try {
                        Thread.sleep(500);
                        t.interrupt();
                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }
                }
            });

        }catch ( Exception e ){
            e.printStackTrace();
        }

        return v;
    }

    @Override
    public void upDate() {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        myViewPager2 = _root.findViewById(R.id.viewPager2);
                        _adapter = new PageAdapter(getParentFragmentManager(),getLifecycle());
                        //subFragments
                        _adapter.addFragment(new result1(_data));
                        _adapter.addFragment(new result2(_data));
                        _adapter.addFragment(new result3(_data));
                        _adapter.addFragment(new result4(_data));

//        myViewPager2.setOrientation(ViewPager2.ORIENTATION_HORIZONTAL);
                        myViewPager2.setAdapter(_adapter);
                    }
                });
            }
        });
        t.start();
        try {
            Thread.sleep(500);
            t.interrupt();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    //文字元件指向與資訊擺放
    private void setText( int id , String txt , View view )
    {
        try
        {
            TextView tv;
            tv = view.findViewById( id );
            tv.setText( txt );
        }catch ( Exception e )
        {
            e.printStackTrace();
        }
    }
}