package com.my.notebook.myapplication;

import java.util.HashMap;
import java.util.Map;

public class MyAccount
{
    public String payType = "";//項目
    public String tradeType = "";//交易類型
    public String detail = "";//細項
    public int money = 0;//金額
    public String Date = "";//日期
    public String Time = "";//時間

    public MyAccount() {}

    public MyAccount(MyAccount accountData)
    {
        payType = accountData.payType;
        tradeType = accountData.tradeType;
        detail = accountData.detail;
        money = accountData.money;
        Date = accountData.Date;
        Time = accountData.Time;
    }

    void reset()
    {
        payType = "";
        tradeType = "";
        detail = "";
        money = 0;
        Date = "";
        Time = "";
    }

    public HashMap<String, Object> toMap()
    {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        ret.put("payType", payType);
        ret.put("tradeType", tradeType);
        ret.put("detail", detail);
        ret.put("money", money);
        ret.put("Date", Date);
        ret.put("Time", Time);
        return ret;
    }
    /*
    public String get( Map<String, Object> map , String key , String defStr )
    {
        try
        {
            return (String) map.get( key );
        }catch ( Exception e )
        {

        }
        return defStr ;
    }

    public int get( Map<String, Object> map , String key , int  defInt )
    {
        try
        {
            return Integer.parseInt( map.get( key ).toString());
        }catch ( Exception e )
        {

        }
        return defInt ;
    }

    public void fromMap( Map<String, Object> data )
    {
        payType = get( data , "" , name ) ;
        salary = get( data , "salary" , salary ) ;
        profession = get( data , "profession" , profession ) ;
        budget = get( data , "budget" , budget ) ;
    }*/
}
