package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomePage extends AppCompatActivity {
    private Button btnIncome;
    private Button btnOutcome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        btnIncome = (Button) findViewById(R.id.btnIncome);
        btnIncome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                b();
            }
        });

        btnOutcome = (Button) findViewById(R.id.btnOutcome);
        btnOutcome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                c();
            }
        });

    }
    private void b() {

        Intent intent = new Intent(HomePage.this, Income.class);
        startActivity(intent);

    }

    private void c() {

        Intent intent = new Intent(HomePage.this, Outcome.class);
        startActivity(intent);

    }

}
