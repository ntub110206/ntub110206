package com.example.project1;

import static android.content.Intent.*;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                a();
            }
        });

    }

    private void a() {


        EditText txtUsername = findViewById(R.id.etUserName);
        EditText txtPassword = findViewById(R.id.etPassword);

        String username = txtUsername.getText().toString();
        String Password = txtPassword.getText().toString();

        if(username.equals("user01") && Password.equals("123456")){

            Intent intent = new Intent(MainActivity.this, HomePage.class);
            startActivity(intent);
        }
        else {
            String message = "username or password incorrect.";

            TextView tvmsg = findViewById(R.id.tvmessage);

            tvmsg.setText(message);
        }
    }
}



