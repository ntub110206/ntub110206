package com.my.notebook.myapplication;

import android.content.DialogInterface;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import androidx.appcompat.app.AlertDialog;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import com.my.notebook.myapplication.ui.main.FragmentInterface;
import com.my.notebook.myapplication.ui.main.SectionsPagerAdapter;
import com.my.notebook.myapplication.databinding.ActivityMainBinding;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity
    implements MyData.MyDataListen
{

    private final MainActivity THIS = this ;
    private MyData _data ;//= new MyData();

    private ActivityMainBinding binding;

    SectionsPagerAdapter _pager ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.
        _data = new MyData( THIS , this , _callCloudListener );

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SectionsPagerAdapter sectionsPagerAdapter = _pager = new SectionsPagerAdapter(this, getSupportFragmentManager() , _data );
        ViewPager viewPager = binding.viewPager;
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = binding.tabs;
        tabs.setupWithViewPager(viewPager);


        FloatingActionButton fab = binding.fab ;

        fab.setOnClickListener( _onAddData );
        //
        _data.getValue();
    }

    //
    private final MyData.CallCloudListener _callCloudListener = new MyData.CallCloudListener()
    {
        @Override
        public void onReturn( boolean isOk, Object inData )
        {
            _pager.upDate2();
        }
    };
    //
    //
    //
    // 新增
    private final View.OnClickListener _onAddData = new View.OnClickListener()
    {
        @Override
        public void onClick(View view)
        {
            MyDataListen_OnAdd( null );
        }
    };

    //
    //
    @Override
    public void MyDataListen_OnAdd( Calendar cal )
    {
        if( _data.noLogin())
        {
            Toast.makeText( this , "沒有登入" , Toast.LENGTH_LONG ) ;
            return ;
        }
        // 下訊息
            /*
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();*/

        MyAddView v = new MyAddView( THIS , _data ) ;

        new AlertDialog.Builder(THIS)
                .setView( v )
                .setTitle("新增")
                //     .setMessage("Are you sure you want to delete this entry?")

                // Specifying a listener allows you to take an action before dismissing the dialog.
                // The dialog is automatically dismissed when a dialog button is clicked.
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which)
                    {
                        v.Save( binding.getRoot() , cal );
                 //       _callCloudListener.onReturn( false ,  );
                    }
                })

                // A null listener allows the button to dismiss the dialog and take no further action.
                .setNegativeButton(android.R.string.no, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    @Override
    public void MyDataListen_OnDel( MyData.ITEM item )
    {

        new AlertDialog.Builder(THIS)
               .setMessage( item._src )
                .setTitle("移除")
                //     .setMessage("Are you sure you want to delete this entry?")

                // Specifying a listener allows you to take an action before dismissing the dialog.
                // The dialog is automatically dismissed when a dialog button is clicked.
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which)
                    {
                        _data.delItem( item );
                    }
                })

                // A null listener allows the button to dismiss the dialog and take no further action.
                .setNegativeButton(android.R.string.no, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }
}