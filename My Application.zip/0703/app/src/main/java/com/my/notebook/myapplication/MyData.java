package com.my.notebook.myapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MyData
{
    final private Set<String> _set = new HashSet<String>();

    final Context _context ;
    //
    //
    int _index = 0 ;
    //
    private final MyDataListen _listener;


    //
    public interface MyDataListen
    {
        public void MyDataListen_OnAdd( Calendar cal );
    }
    //
    //
    public class TOTAL
    {
        public final String _name ; // 大項名稱
        public final int _totalMoney ; // 總金額
        public final float _pi ; // 比例
        public TOTAL( String name , int totalMoney , float pi )
        {
            _name = name ;
            _totalMoney = totalMoney ;
            _pi = pi ;
        }
    }
    //
    //
    public class DATA_YYMMDD
    {
        public final int _yy ; // 年
        public final int _mm ; // 月
        public final int _dd ; // 日

        final List<ITEM> _buf = new ArrayList<>(); // 當天消費項目

        DATA_YYMMDD( int yy , int mm , int dd )
        {
            _yy = yy ;
            _mm = mm ;
            _dd = dd ;
        }
        public void add( ITEM item )
        {
            _buf.add( item );
        }

        public boolean check( int yy, int mm , int dd )
        {
            if( _dd == dd )
            if( _yy == yy )
                return _mm == mm ;
            return false ;
        }
        //
        public Calendar toCalender()
        {
            Calendar ret = Calendar.getInstance();
            ret.set( Calendar.YEAR , _yy );
            ret.set( Calendar.MONTH , _mm -1 );
            ret.set( Calendar.DAY_OF_MONTH , _dd );
            return ret ;
        }
    }
    //

    //

    public class ITEM
    {
        final public String A ; // 大項
        final public String B ; // 小項
        final public int money ; // 金額
        final public int yy ; // 年
        final public int mon ; // 月
        final public int dd ; // 日
        final public int hh ; // 時
        final public int mm ; // 分
        final public String _src ; // 資料
        final private String [] _split; // 分割後

        ITEM( String str ) throws Exception
        {
            _split = str.split( "\t" );
            _src = str ;
            A = _split[1] ;
            B = _split[2] ;
            money = Integer.parseInt( _split[3] );
            String [] ssa = _split[0].split( " " );
            String [] ss = ssa[0].split( "/"  );

            yy = Integer.parseInt( ss[0] );
            mon = Integer.parseInt( ss[1] );
            dd = Integer.parseInt( ss[2] );

            String [] ss2 = ssa[1].split( ":" );
            hh = Integer.parseInt( ss2[0] );
            mm = Integer.parseInt( ss2[1] );

        }

        @Override
        public String toString()
        {
            return String.format( "%s %s %d" , A , B , money );
        }
    }

    public static final String FILD_NAME = "MyData_DATA" ;

    public static final String mode[]       = new String[]{"食","衣","行" , "樂" , "月結"} ;
    public static final String mode0_item[] = new String[]{"自煮" , "餐館","飲料" } ;

    public static final String mode1_item[] = new String[]{"外出服" , "休閒服" , "鞋" , "包"} ;

    public static final String mode2_item[] = new String[]{"加油" , "計程車" , "大眾運輸" , "高鐵"} ;

    public static final String mode3_item[] = new String[]{"遊戲" , "電影" , "景點" , "紅包"} ;

    public static final String mode4_item[] = new String[]{"水費" , "電費" , "通信" } ;



    public static String[] getItem( long sel )
    {
        String ret[] = mode0_item ;
        if( sel == 1 )
            ret = MyData.mode1_item ;
        else if( sel == 2 )
            ret =  MyData.mode2_item ;
        else if( sel == 3 )
            ret =  MyData.mode3_item ;
        else if( sel == 4 )
            ret =  MyData.mode4_item ;
        return ret ;
    }



    public MyData( Context context , MyDataListen listener )
    {
        _context = context ;
        _listener = listener ;
        SharedPreferences sp = context.getSharedPreferences( FILD_NAME , Context.MODE_PRIVATE );
        Set<String> set = sp.getStringSet( "SET" , new HashSet<String>() );
        _set.addAll( set );
        _index = _set.size() ;
    }
    public String add(  Calendar calendar , String a, String b, int money )
    {
        //
        // 加入
        if( calendar == null )
            calendar = Calendar.getInstance();

        _index ++ ;
        int yy = calendar.get( Calendar.YEAR );
        int mon = calendar.get( Calendar.MONTH ) + 1 ;
        int dd = calendar.get( Calendar.DAY_OF_MONTH );
        int hh = calendar.get( Calendar.HOUR_OF_DAY );
        int mm = calendar.get( Calendar.MINUTE );
        String ret =  String.format( "%04d/%02d/%02d %02d:%02d\t%s\t%s\t%d\t%d"
                , yy , mon , dd , hh , mm , a , b , money , _index
        ) ;
        _set.add( ret  );
        // 存檔
        SharedPreferences sp = _context.getSharedPreferences( FILD_NAME, Context.MODE_PRIVATE );
        SharedPreferences.Editor edit = sp.edit() ;
        Set<String> strings = new HashSet<>();
        strings.addAll( _set );
        edit.putStringSet( "SET" , strings );
        if( false == edit.commit())
        {
            Toast.makeText( _context , "err" , Toast.LENGTH_LONG );
        }

        return ret ;
    }

    //
    //
    public static boolean checkYYMMDD( Calendar a , Calendar b )
    {
        if( a.get( Calendar.YEAR ) == b.get( Calendar.YEAR ))
            if( a.get( Calendar.MONTH ) == b.get( Calendar.MONTH ))
                if( a.get( Calendar.DAY_OF_MONTH ) == b.get( Calendar.DAY_OF_MONTH ))
                    return true ;
                return false ;
    }
    // get
    public ITEM[] getItem()
    {
        ArrayList<ITEM> list = new ArrayList<>();
        for( final String s : _set )
        {
            try
            {
                list.add( new ITEM( s ) );
            }catch ( Exception e )
            {

            }

        }

        return list.toArray( new ITEM[list.size()]) ;
    }

    // get
    public ITEM[] getItem( int yy , int mm , int dd )
    {
        String str = String.format( "%04d/%02d/%02d " , yy , mm , dd );
        ArrayList<ITEM> list = new ArrayList<>();
        for( final String s : _set )
        {
            if( s.indexOf( str  ) != 0 )
                continue;
            try
            {
                list.add( new ITEM( s ) );
            }catch ( Exception e )
            {

            }

        }

        return list.toArray( new ITEM[list.size()]) ;
    }

    //
    static public int modeIndex( String name )
    {
        int i ;
        for( i = 0 ; i < mode.length ; ++i  )
            if( mode[i].compareTo( name ) == 0 )
                return i ;
        return -1 ;
    }
    //
    public TOTAL[] getTotal()
    {
        int i ;
        TOTAL[] ret = new TOTAL[mode.length] ;
        int mon[] = new int[mode.length] ;
        int total = 0 ;
        ITEM[] item = getItem() ;
        for( ITEM ii : item )
        {
            try
            {
                int index = modeIndex( ii.A );
                mon[index] += ii.money ;
                total +=  ii.money ;
            } catch ( Exception e )
            {

            }
        }

        if( total == 0 )
            total = 1 ;
        for( i = 0 ; i < ret.length ; ++i )
            ret[i] = new TOTAL( mode[i] , mon[i] , (float)mon[i] / (float)total );
        return ret ;

    }

    //
    public void onAdd(  Calendar cal  )
    {
        _listener.MyDataListen_OnAdd( cal );
    }

    //
    public DATA_YYMMDD[] getSet()
    {
        int i ;
        DATA_YYMMDD yymm = null;
        List<DATA_YYMMDD> ret = new ArrayList<>();
        ITEM[]items =  getItem() ;
        for( ITEM item : items )
        {
            for( i = 0 ; i < ret.size() ; ++i )
            {
                 yymm = ret.get( i );
                if( yymm.check( item.yy , item.mon , item.dd ))
                    break ;
            }

            if( i == ret.size())
            {
                yymm = new DATA_YYMMDD( item.yy , item.mon , item.dd );
                ret.add( yymm  );
            }
            yymm.add( item );

        }

        return ret.toArray( new DATA_YYMMDD[ret.size()]) ;
    }
}


