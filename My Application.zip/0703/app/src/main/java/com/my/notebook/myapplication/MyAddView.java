package com.my.notebook.myapplication;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;

import com.google.android.material.snackbar.Snackbar;

import java.util.Calendar;

public class MyAddView extends LinearLayout
{
    final MyAddView THIS = this ;
    final MyData _data ;
    final View _root ;
    final Spinner _spinner ;
    final ArrayAdapter _typeAdapter ;


    final Spinner _childSpinner ;

    final EditText _moneyEdit;

    public MyAddView(Context context , MyData myData )
    {
        super(context);
        _data = myData ;
        LayoutInflater inflater = LayoutInflater.from(context);
        _root  = inflater.inflate(R.layout.view_add, null, false);
        _spinner = _root.findViewById( R.id.id_type_spinner );


        _typeAdapter = new ArrayAdapter(
                context , android.R.layout.simple_dropdown_item_1line ,
                MyData.mode );
        _spinner.setAdapter( _typeAdapter );

        _spinner.setOnItemSelectedListener( _onItemSelectListener );

        _childSpinner = _root.findViewById( R.id.id_type_child_spinner );

        _moneyEdit = _root.findViewById( R.id.id_edit_money );
        this.addView( _root );
        _update();

    }

    // 主項選擇
    AdapterView.OnItemSelectedListener _onItemSelectListener = new AdapterView.OnItemSelectedListener()
    {
        @Override
        public void onItemSelected( AdapterView<?> adapterView, View view, int i, long l )
        {
            _update();

        }

        @Override
        public void onNothingSelected( AdapterView<?> adapterView )
        {

        }
    };


    // 更新畫面
    private void _update()
    {
        //
        final Runnable runnable = new Runnable()
        {
            @Override
            public void run()
            {
                long sel = _spinner.getSelectedItemId();
                String item[] = MyData.getItem( sel );

                ArrayAdapter adapter = new ArrayAdapter(
                        THIS.getContext() , android.R.layout.simple_dropdown_item_1line ,
                        item);

                _childSpinner.setAdapter( adapter );
            }
        };
        // 更新
        new Handler( Looper.getMainLooper()).postDelayed( runnable , 0 );

    }
    //
    public void Save( View view , Calendar cal  )
    {
        try
        {


            String a = _spinner.getSelectedItem().toString();
            String b = _childSpinner.getSelectedItem().toString();
            int mm = Integer.parseInt( _moneyEdit.getText().toString() );
            String ret = _data.add( cal , a , b , mm );
            Snackbar.make( view, "完成\n" + ret , Snackbar.LENGTH_LONG ).setAction( "Action", null ).show();

        }catch ( Exception e )
        {
            Snackbar.make( view, "失敗", Snackbar.LENGTH_LONG ).setAction( "Action", null ).show();

        }
    }



}
