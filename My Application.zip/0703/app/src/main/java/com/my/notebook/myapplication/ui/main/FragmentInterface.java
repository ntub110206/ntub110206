package com.my.notebook.myapplication.ui.main;

public interface FragmentInterface {
    void upDate();
}
