package com.my.notebook.myapplication;

import android.content.DialogInterface;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import androidx.appcompat.app.AlertDialog;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.view.LayoutInflater;
import android.view.View;

import com.my.notebook.myapplication.ui.main.SectionsPagerAdapter;
import com.my.notebook.myapplication.databinding.ActivityMainBinding;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity
    implements MyData.MyDataListen
{

    private final MainActivity THIS = this ;
    private MyData _data ;//= new MyData();

    private ActivityMainBinding binding;

    SectionsPagerAdapter _pager ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.
        _data = new MyData( this.getApplicationContext() , this );

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SectionsPagerAdapter sectionsPagerAdapter = _pager = new SectionsPagerAdapter(this, getSupportFragmentManager() , _data );
        ViewPager viewPager = binding.viewPager;
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = binding.tabs;
        tabs.setupWithViewPager(viewPager);


        FloatingActionButton fab = binding.fab ;

        fab.setOnClickListener( _onAddData );
    }

    // 新增
    private final View.OnClickListener _onAddData = new View.OnClickListener()
    {
        @Override
        public void onClick(View view)
        {
            MyDataListen_OnAdd( null );
        }
    };

    @Override
    public void MyDataListen_OnAdd( Calendar cal )
    {
        // 下訊息
            /*
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();*/

        MyAddView v = new MyAddView( THIS , _data ) ;

        new AlertDialog.Builder(THIS)
                .setView( v )
                .setTitle("新增")
                //     .setMessage("Are you sure you want to delete this entry?")

                // Specifying a listener allows you to take an action before dismissing the dialog.
                // The dialog is automatically dismissed when a dialog button is clicked.
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which)
                    {
                        v.Save( binding.getRoot() , cal );
                        _pager.upDate();
                        // Continue with delete operation
                    }
                })

                // A null listener allows the button to dismiss the dialog and take no further action.
                .setNegativeButton(android.R.string.no, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }
}