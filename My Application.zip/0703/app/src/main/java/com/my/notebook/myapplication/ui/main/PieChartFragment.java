package com.my.notebook.myapplication.ui.main;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.my.notebook.myapplication.MyData;
import com.my.notebook.myapplication.R;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/*



  圓餅圖



 */
public class PieChartFragment extends Fragment
        implements FragmentInterface
{
    private final MyData _data ;

    private PieChart _pieChart;

    private View _root ;

    private ListView _listView ;


    public PieChartFragment( MyData data )
    {
        super();
        _data = data ;
    }
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {

        final View root = _root =inflater.inflate(R.layout.fragment_main_pie_chart, container, false);

        _pieChart = root.findViewById( R.id.pieChart );

        _listView = _root.findViewById( R.id.list_view );

        initPage();
        return root ;

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    private void initPage()
    {
        int i ;

        // 顯示百分比
        _pieChart.setUsePercentValues(true);
        // 描述信息
        //    _pieChart
        //  _pieChart.setDescription("測試餅圖");
        // 設置偏移量
        _pieChart.setExtraOffsets(5, 10, 5, 5);
        // 設置滑動減速摩擦系數
        _pieChart.setDragDecelerationFrictionCoef(0.95f);


        // 中心設定
        /* 設置餅圖中心是否是空心的 true 中間是空心的，環形圖 false 中間是實心的 餅圖 */
        _pieChart.setDrawHoleEnabled(false);

        if( false )
        {
            _pieChart.setCenterText("測試餅圖，中間文字");
            /* 設置餅圖中心是否是空心的 true 中間是空心的，環形圖 false 中間是實心的 餅圖 */
            _pieChart.setDrawHoleEnabled(true);
            /* 設置中間空心圓孔的顏色是否透明 true 透明的 false 非透明的 */
            //   _pieChart.setHoleColorTransparent(true);
            // 設置環形圖和中間空心圓之間的圓環的顏色
            _pieChart.setTransparentCircleColor(Color.WHITE);
            // 設置環形圖和中間空心圓之間的圓環的透明度
            _pieChart.setTransparentCircleAlpha(0);

            // 設置圓孔半徑
            _pieChart.setHoleRadius(58f);
            // 設置空心圓的半徑
            _pieChart.setTransparentCircleRadius(61f);
            // 設置是否顯示中間的文字
            _pieChart.setDrawCenterText(true);
        }

        // 設置旋轉角度   ？？
        _pieChart.setRotationAngle(0);
        // enable rotation of the chart by touch
        _pieChart.setRotationEnabled(true);
        _pieChart.setHighlightPerTapEnabled(false);

        // add a selection listener
        // mPieChart.setOnChartValueSelectedListener(this);
        MyData.TOTAL total[] = _data.getTotal();
        TreeMap<String, Float> data = new TreeMap<>();
        for( MyData.TOTAL tt : total )
        {
            data.put( tt._name , tt._pi );
        }


        String strArr[] = new String[total.length];
        for( i=  0 ; i < strArr.length ; ++i )
            strArr[i] = String.format( total[i]._name + ":" + total[i]._totalMoney + "元") ;
        ArrayAdapter adapter = new ArrayAdapter( this.getContext()
                , android.R.layout.simple_dropdown_item_1line
                , strArr
        );
        _listView.setAdapter( adapter );

        setData(data);

        // 設置動畫
        _pieChart.animateY(1400, Easing.EasingOption.EaseInOutQuad);

        // 設置顯示的比例
        Legend l = _pieChart.getLegend();
        l.setPosition(Legend.LegendPosition.RIGHT_OF_CHART);
        l.setXEntrySpace(7f);
        l.setYEntrySpace(0f);
        l.setYOffset(0f);
    }


    public void setData(TreeMap<String, Float> data) {
        ArrayList<String> xVals = new ArrayList<String>();
        ArrayList<PieEntry> yVals1 = new ArrayList<PieEntry>();

        int i = 0;
        Iterator it = data.entrySet().iterator();
        while (it.hasNext()) {
            // entry的輸出結果如key0=value0等
            Map.Entry entry = (Map.Entry) it.next();
            String key = (String) entry.getKey();
            float value = (float) entry.getValue();
            xVals.add(key);
            yVals1.add(new PieEntry(value, key ));
        }

        PieDataSet dataSet = new PieDataSet(yVals1, "花費明細");
        // 設置餅圖區塊之間的距離
        dataSet.setSliceSpace(2f);
        dataSet.setSelectionShift(5f);

        // 添加顏色
        ArrayList<Integer> colors = new ArrayList<Integer>();
        for (int c : ColorTemplate.VORDIPLOM_COLORS)
            colors.add(c);
        for (int c : ColorTemplate.JOYFUL_COLORS)
            colors.add(c);
        for (int c : ColorTemplate.COLORFUL_COLORS)
            colors.add(c);
        for (int c : ColorTemplate.LIBERTY_COLORS)
            colors.add(c);
        for (int c : ColorTemplate.PASTEL_COLORS)
            colors.add(c);
        colors.add(ColorTemplate.getHoloBlue());
        dataSet.setColors(colors);
        // dataSet.setSelectionShift(0f);

        PieData data1 = new PieData( dataSet);
        data1.setValueFormatter(new PercentFormatter());
        data1.setValueTextSize(10f);
        data1.setValueTextColor(Color.BLACK);
     //   data1.set
        _pieChart.setData(data1);

        // undo all highlights
        _pieChart.highlightValues(null);

        _pieChart.invalidate();
    }

    @Override
    public void upDate() {
        initPage();
    }
}
