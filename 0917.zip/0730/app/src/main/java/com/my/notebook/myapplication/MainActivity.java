package com.my.notebook.myapplication;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Environment;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;
import android.widget.EditText;

import com.my.notebook.myapplication.ui.main.FragmentInterface;
import com.my.notebook.myapplication.ui.main.SectionsPagerAdapter;
import com.my.notebook.myapplication.databinding.ActivityMainBinding;

import org.jetbrains.annotations.NotNull;

import java.util.Calendar;
import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity
    implements MyData.MyDataListen
{

    private final MainActivity THIS = this ;
    private MyData _data ;//= new MyData();

    private ActivityMainBinding binding;

    private View _root ;
    private EditText moneyText;

    SectionsPagerAdapter _pager ;

    //
    //
    private MyAddView _addView = null ;
   // @RequiresApi(api = Build.VERSION_CODES.R)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_add);
        moneyText = findViewById(R.id.id_edit_money);

        // creating a client
        OkHttpClient okHttpClient = new OkHttpClient();

        // building a request
        Request request = new Request.Builder().url("http://192.168.1.108:5000/").build();

        // making call asynchronously
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            // called if server is unreachable
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "server down", Toast.LENGTH_SHORT).show();
                        moneyText.setText("error connecting to the server");
                    }
                });
            }

            @Override
            // called if we get a
            // response from the server
            public void onResponse(
                    @NotNull Call call,
                    @NotNull Response response)
                    throws IOException {moneyText.setText(response.body().string());
            }
        });

        this._data = new MyData( THIS , this , _callCloudListener );

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView( _root = binding.getRoot());

        SectionsPagerAdapter sectionsPagerAdapter = _pager = new SectionsPagerAdapter(this, getSupportFragmentManager() , _data );
        ViewPager viewPager = binding.viewPager;
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = binding.tabs;
        tabs.setupWithViewPager(viewPager);


        FloatingActionButton fab = binding.fab ;

        fab.setOnClickListener( _onAddData );
        //
        _data.getValue();

    }

    //
    //
    @Override
    public void MyDataListen_OnPermissions()
    {
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        //
        /*
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if(!Environment.isExternalStorageManager()){
                Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                startActivity(intent);
                return;
            }
        }*/
    }
    //
    private final MyData.CallCloudListener _callCloudListener = new MyData.CallCloudListener()
    {
        @Override
        public void onReturn( boolean isOk, Object inData )
        {
            _pager.upDate2();
        }
    };
    //
    // TODO: 20220729
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode , resultCode , data);
        if( _addView == null )
            return ;
        _addView.onIntent( requestCode , resultCode , data );

    }
    //
    // 新增
    private final View.OnClickListener _onAddData = new View.OnClickListener()
    {
        @Override
        public void onClick(View view)
        {
            MyDataListen_OnAdd( null );
        }
    };

    //
    //
    @Override
    public void MyDataListen_OnAdd( Calendar cal )
    {
        if( _data.noLogin())
        {

            Snackbar.make( _root , "沒有登入", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
            return ;
        }
        // 下訊息
            /*
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();*/

        MyAddView v = _addView = new MyAddView( THIS , _data , null ) ;

        new AlertDialog.Builder(THIS)
                .setView( v )
                .setTitle("新增")
                //     .setMessage("Are you sure you want to delete this entry?")

                // 確定鈕
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which)
                    {
                        v.Save( binding.getRoot() , cal );
                        _addView = null ;
                    }
                })
                // 關閉
                .setOnDismissListener( new DialogInterface.OnDismissListener()
                {
                    @Override
                    public void onDismiss( DialogInterface dialogInterface )
                    {
                        _addView = null ;
                    }
                } )
                // 取消鈕
                .setNegativeButton(android.R.string.no, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    @Override
    public void MyDataListen_OnDel( MyData.ITEM item )
    {

        new AlertDialog.Builder(THIS)
               .setMessage( item._src )
                .setTitle("移除")
                //     .setMessage("Are you sure you want to delete this entry?")

                // Specifying a listener allows you to take an action before dismissing the dialog.
                // The dialog is automatically dismissed when a dialog button is clicked.
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which)
                    {
                        _data.delItem( item );
                    }
                })

                // A null listener allows the button to dismiss the dialog and take no further action.
                .setNegativeButton(android.R.string.no, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    // TODO: 20220718
    @Override
    public void MyDataListen_OnUpdate( MyData.ITEM item )
    {
        if( _data.noLogin())
        {
            Snackbar.make( _root , "沒有登入", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
            return ;
        }

        Calendar cal = Calendar.getInstance();
        cal.set( item.yy , item.mon -1 , item.dd , item.hh , item.mm);
        // TODO: 20220718
        MyAddView v = _addView = new MyAddView( THIS , _data , item ) ;

        new AlertDialog.Builder(THIS)
                .setView( v )
                .setTitle("修改")

                // 確定鈕
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which)
                    {
                        v.Save( binding.getRoot() , cal );
                        _addView = null ;
                    }
                })
                // 關閉
                .setOnDismissListener( new DialogInterface.OnDismissListener()
                {
                    @Override
                    public void onDismiss( DialogInterface dialogInterface )
                    {
                        _addView = null ;
                    }
                } )
                // 取消鈕
                .setNegativeButton(android.R.string.no, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }
    //
    // TODO: 20220729
    @Override
    public void MyDataListen_OnMessage( String msg )
    {
        Snackbar.make( _root , msg , Snackbar.LENGTH_LONG ).setAction( "Action", null ).show();

    }
}