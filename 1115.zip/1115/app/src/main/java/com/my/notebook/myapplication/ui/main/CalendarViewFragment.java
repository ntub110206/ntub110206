
package com.my.notebook.myapplication.ui.main;

import com.applandeo.materialcalendarview.EventDay;
import com.applandeo.materialcalendarview.listeners.OnDayClickListener;
import com.applandeo.materialcalendarview.CalendarView ;


import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.my.notebook.myapplication.MyData;
import com.my.notebook.myapplication.R;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/*

  日曆表

 */
public class CalendarViewFragment extends Fragment
        implements FragmentInterface
{


    private final MyData _data;

    private View _root;
    private CalendarView _calendarView;

    private List<EventDay> _event = new ArrayList<EventDay>();

    private Calendar _lastCalender = Calendar.getInstance() ;

    private LinearLayout _dataRoot ;



    public CalendarViewFragment( MyData data )
    {
        super();
        _data = data;
    }

    @Override
    public void onCreate( Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );

    }

    @Override
    public View onCreateView( @NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState )
    {

        _root = inflater.inflate( R.layout.fragment_main_calendar_view, container, false );
        _calendarView = _root.findViewById( R.id.calendarView );
        _dataRoot = _root.findViewById( R.id.list_data );

        _calendarView.setOnDayClickListener( _onDayClickListener);



        upDate();

        return _root ;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    //
    private final OnDayClickListener _onDayClickListener = new OnDayClickListener()
    {
        @Override
        public void onDayClick( EventDay eventDay )
        {
            //    _event.add(new EventDay(eventDay, R.drawable.ic_baseline_save_24));

            try
            {
                Calendar exitCal = _lastCalender ;
                Calendar cal = _lastCalender = eventDay.getCalendar();

                updateList();

                _calendarView.setDate( eventDay.getCalendar() );

                //     List<EventDay> event = new ArrayList<>();
                //      event.add(new EventDay(eventDay.getCalendar() , R.drawable.ic_baseline_attach_money_24));
                //      _calendarView.setEvents(event);
                /*
                runOnUiThread(() -> {
                    /**刷新介面*/
                //    _calendarView.setEvents(event);

                if( MyData.checkYYMMDD( exitCal , cal )== false )
                {
                    return ;
                }
                _data.onAdd( cal );
                // newData();
            } catch ( Exception e )
            {
                e.printStackTrace();
            }
        }
    };
    //
    //
    void updateList()
    {
        Calendar cal = _lastCalender ;
        _dataRoot.removeAllViews();
        MyData.ITEM items[] = _data.getItem( cal.get( Calendar.YEAR ) ,  cal.get( Calendar.MONTH ) + 1 ,  cal.get( Calendar.DAY_OF_MONTH)
        );
        Log.d("cal",items.toString());

        for( MyData.ITEM ii : items )
        {
            String str = ii.toString();
            TextView tv = new TextView( getContext() );
            tv.setText( str );
            Log.d("item",str);
            //     tv.setTextColor( Color.BLACK ); // TODO: 20220718 風格
            //     tv.setBackgroundColor( Color.WHITE );// TODO: 20220718 風格
            tv.setTag( ii );
            tv.setOnLongClickListener( _onItemLongClickListener );
            tv.setOnClickListener( __onItemClickListener ); // TODO: 20220718
            _dataRoot.addView(tv);
        }

    }
    //
    //
    private final View.OnLongClickListener _onItemLongClickListener = new View.OnLongClickListener()
    {

        @Override
        public boolean onLongClick( View view )
        {
            Object tag = view.getTag();
            if( MyData.ITEM.class.isInstance( tag ))
            {

                MyData.ITEM item = ( MyData.ITEM)tag ;
                _data.onDel( item );
            }
            return false;
        }
    };
    //
    // TODO: 20220718
    private final View.OnClickListener __onItemClickListener = new View.OnClickListener()
    {
        @Override
        public void onClick( View view )
        {
            Object tag = view.getTag();
            if( MyData.ITEM.class.isInstance( tag ))
            {

                MyData.ITEM item = ( MyData.ITEM)tag ;
                _data.onUpdate( item );
            }
        }
    };
    //
    //
    @Override
    public void upDate() {

        List<EventDay> event = new ArrayList<>();
        Calendar date = _calendarView.getCurrentPageDate() ;
        int yy = date.get( Calendar.YEAR );
        int mm = date.get( Calendar.MONTH ) + 1 ;
        MyData.DATA_YYMMDD[] dates = _data.getSet();

        for( MyData.DATA_YYMMDD item : dates )
        {//event.add(new EventDay(calendar, R.drawable.ic_baseline_save_24));
            Log.d("dates",item.toString());
            event.add( new EventDay( item.toCalender() , R.drawable.ic_baseline_attach_money_24 )  );
        }
        Log.d("event",event.toString());
        _calendarView.setEvents( event );

        //
        updateList() ;

    }



}

