package com.my.notebook.myapplication.ui.main;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.PieChart;
import com.my.notebook.myapplication.MyData;
import com.my.notebook.myapplication.MyUser;
import com.my.notebook.myapplication.R;

public class SuperPage extends Fragment
        implements FragmentInterface
{
    private final SuperPage THIS= this ;
    private final MyData _data ;

    private PieChart _pieChart;

    private View _root ;


    public SuperPage( MyData data )
    {
        super();
        _data = data ;

    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {

        final View root = _root =inflater.inflate(R.layout.fragment_main_super_page, container, false);

     //   upDate();
        _data.getUserData( this._onFirebaseCallback );

        return root ;

    }

    @Override
    public void upDate()
    {
        /*
        TextView tv ;
        //
        final MyUser user = _data.getUser();
        setText( R.id.my_username , user.user );
        setText( R.id.my_name , user.name );
        setText( R.id.my_budget , user.budget );
        setText( R.id.my_salary , user.salary );
        setText( R.id.my_profession , user.profession );
        */
        //flask
        _data.flaskSetSPTxt(R.id.my_username, R.id.my_name, R.id.my_profession, R.id.my_salary, R.id.my_budget, _root);
    }
    //
    private void setText( int id , Object text )
    {

        try
        {
            TextView tv;
            tv = _root.findViewById( id );
            tv.setText( text.toString() );
        }catch ( Exception e )
        {

        }

    }

    //

    //
    private final MyData.CallCloudListener _onFirebaseCallback = new MyData.CallCloudListener()
    {

        @Override
        public void onReturn( boolean isOk, Object inData )
        {
            upDate();
        }
    };


    private String get( int id , String value )
    {
        try
        {
            TextView tv = _root.findViewById( id );
            return tv.getText().toString();
        }catch ( Exception e )
        {

        }
        return value ;
    }
    private int get( int id , int value )
    {
        try
        {
            TextView tv = _root.findViewById( id );
            return Integer.parseInt( tv.getText().toString() );
        }catch ( Exception e )
        {

        }
        return value ;

    };


}
