package com.my.notebook.myapplication;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.List;

public class MyAddView extends LinearLayout
{

    static final String TAG = "MyAddView" ;
    final MyAddView THIS = this ;
    final MyData _data ;
    final View _root ;
    final Spinner _spinner ;
    final ArrayAdapter _typeAdapter ;


    final Spinner _childSpinner ;

    final EditText _moneyEdit;

    // TODO: 20220718
    final MyData.ITEM _srcItem ;

    // TODO: 20220729
    Bitmap _bmp = null ;
    final Activity _activity ;

    final ImageView _imageView  ;

    File _camera_photo_name = null ;
    //
    public MyAddView(Activity activity , MyData myData , MyData.ITEM srcItem  )
    {
        super(activity);
        // TODO: 20220718
        _srcItem = srcItem ;

        _activity = activity ;

        _data = myData ;
        LayoutInflater inflater = LayoutInflater.from(activity);
        _root  = inflater.inflate(R.layout.view_add, null, false);
        _spinner = _root.findViewById( R.id.id_type_spinner );


        _typeAdapter = new ArrayAdapter(
                activity , android.R.layout.simple_dropdown_item_1line ,
                MyData.mode );
        _spinner.setAdapter( _typeAdapter );

        _spinner.setOnItemSelectedListener( _onItemSelectListener );

        _childSpinner = _root.findViewById( R.id.id_type_child_spinner );

        _moneyEdit = _root.findViewById( R.id.id_edit_money );

        //
        // TODO: 20220729
        // 拍照
        _root.findViewById(R.id.bn_camera ) .setOnClickListener( v ->
                _openCamera()
        );
        // 照片櫃
        _root.findViewById(R.id.bn_select ) .setOnClickListener( v ->
                _selectFile()
        );
        // 圖
        _imageView = _root.findViewById(R.id.iv_image );
        //
        //
        this.addView( _root );

        //
        // TODO: 20220718
        new Handler( Looper.getMainLooper())
        {
            @Override
            public void handleMessage( @NonNull Message msg )
            {
                _update();
                super.handleMessage(msg);
            }
        }.sendEmptyMessage(0);



        //
        if( _srcItem != null )
        {
            _spinner.post(new Runnable()
            {
                @Override
                public void run()
                {
                    _moneyEdit.setText( "" + _srcItem.money );
                    final int a = _srcItem.aIndex();
                    if( a < 0 ) return ;
                    _spinner.setSelection( a , true );
                    _update();
                    _childSpinner.post(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            final int b = _srcItem.bIndex();
                            if( b < 0 ) return ;
                            _childSpinner.setSelection( b , true  );

                        }
                    });
                }
            });
        }
        //
        // firebase image
        //
        _fromFirebase();

    }

    //
    //
    //

    // 主項選擇
    // 主項選擇
    AdapterView.OnItemSelectedListener _onItemSelectListener = new AdapterView.OnItemSelectedListener()
    {
        @Override
        public void onItemSelected( AdapterView<?> adapterView, View view, int i, long l )
        {
            _update();

        }

        @Override
        public void onNothingSelected( AdapterView<?> adapterView )
        {

        }
    };


    // 更新畫面
    private void _update()
    {
        long sel = _spinner.getSelectedItemId();
        String item[] = MyData.getItem( sel );

        ArrayAdapter adapter = new ArrayAdapter(
                THIS.getContext() , android.R.layout.simple_dropdown_item_1line ,
                item);

        _childSpinner.setAdapter( adapter );

        /*
        //
        final Runnable runnable = new Runnable()
        {
            @Override
            public void run()
            {
                long sel = _spinner.getSelectedItemId();
                String item[] = MyData.getItem( sel );

                ArrayAdapter adapter = new ArrayAdapter(
                        THIS.getContext() , android.R.layout.simple_dropdown_item_1line ,
                        item);

                _childSpinner.setAdapter( adapter );
            }
        };
        // 更新
        new Handler( Looper.getMainLooper()).postDelayed( runnable , 0 );
*/
    }
    //
    //

    // 拍照
    void _openCamera()
    {
        try
        {
            String path =  new File( Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getCanonicalPath()
                    + "/apps").getAbsolutePath();;
            if (!new File(path).exists()) {
                new File(path).mkdirs();
            }
            File outputImageFile = _camera_photo_name = new File(path, System.currentTimeMillis() + ".png");
            if (!outputImageFile.exists()) {
                try {
                    outputImageFile.createNewFile();
                } catch ( IOException e) {
                    //e.printStackTrace();
                    _data.getListener().MyDataListen_OnPermissions();;
                    _data.getListener().MyDataListen_OnMessage( "無清打開暫存檔，請開啟權限" );
                    return ;
                }
            }
            //兼容7.0
            Uri contentUri = FileProvider.getUriForFile(
                    _activity,
                    BuildConfig.APPLICATION_ID,
                    outputImageFile
            );
            Log.d(TAG, "openCameraWithOutput: uri = " + contentUri.toString());
            Intent intent = new Intent( MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(Intent.EXTRA_MIME_TYPES, MimeTypeMap.getSingleton().getMimeTypeFromExtension("png"));
            //指定輸出路徑
            intent.putExtra(MediaStore.EXTRA_OUTPUT, contentUri);



            _activity.startActivityForResult(intent, 0);
        }catch ( Exception e )
        {
            System.out.println( e.getMessage());
        }
    }

    // 照片櫃
    void _selectFile()
    {
        final String mimeType = "image/png";
        final PackageManager packageManager = getContext().getPackageManager();
        final Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType(mimeType);
        List<ResolveInfo> list = packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
        //  if (list.size() > 0)
        if( true )
        {

            // 如果有可用的Activity
            Intent picker = new Intent(Intent.ACTION_GET_CONTENT);
            picker.setType(mimeType);
            // 使用Intent Chooser
            Intent destIntent = Intent.createChooser(picker, "選取PNG圖片");
            _activity.startActivityForResult(destIntent , 1 );

        } else {
            // 沒有可用的Activity
            //

        }
    }
    //
    public void Save( View view , Calendar cal )
    {
        try
        {


            String a = _spinner.getSelectedItem().toString();
            String b = _childSpinner.getSelectedItem().toString();
            int mm = Integer.parseInt( _moneyEdit.getText().toString() );

            String ret = "" ;
            if( _srcItem != null ) {
                _data.budgetCalculateAfterUpdate(mm, a, _srcItem);
                _data.update(_activity, _bmp, cal, a, b, mm, _srcItem._firebaseId);
            }
            else {
                _data.budgetCalculateAfterAdd(mm,a,view);
                ret = _data.add(_activity, _bmp, cal, a, b, mm);
            }

//            Snackbar.make( view, "完成\n" + ret , Snackbar.LENGTH_LONG ).setAction( "Action", null ).show();

        }catch ( Exception e )
        {
            Snackbar.make( view, "記帳失敗", Snackbar.LENGTH_LONG ).setAction( "Action", null ).show();
        }
    }


    //
    // TODO: 20220729

    //
    public void onIntent( int requestCode , int resultCode , Intent data )
    {

        _bmp = null ;
        if(requestCode == 0 )
        {
            try {

                //            _bmp = (Bitmap) data.getExtras().get("data");
                String fileName = _camera_photo_name.getAbsolutePath();

                final BitmapFactory.Options options = new BitmapFactory.Options();
                options.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(fileName, options);

                // 最大 600 就好
                options.inSampleSize = calculateInSampleSize(options, 600 );
                options.inJustDecodeBounds = false;
                _bmp =  BitmapFactory.decodeFile(fileName, options);
                //    _bmp = BitmapFactory.decodeFile( fileName );
            }catch ( Exception e )
            {
                System.out.println( e.getMessage());
            }

        }else if( requestCode == 1 )
        {
            final Uri uri = data.getData();
            if (uri != null)
            {
                // 單選
                try {
                    _bmp = MediaStore.Images.Media.getBitmap(_activity.getContentResolver(), uri);

                } catch ( IOException e) {
                    e.printStackTrace();
                }

            }

        }

        //      imgFavorite.setImageBitmap(bp);
        if( _bmp == null )return ;

        _imageView.setImageBitmap( _bmp );
        _imageView.setVisibility(View.VISIBLE);
    }


    // 計算縮放比
    public static int calculateInSampleSize(BitmapFactory.Options options,
                                            int reqWidth) {
        // 源圖片的寬度
        final int width = options.outWidth;
        int inSampleSize = 1;
        if (width > reqWidth) {
            // 計算出實際寬度和目標寬度的比率
            final int widthRatio = Math.round((float) width / (float) reqWidth);
            inSampleSize = widthRatio;
        }
        return inSampleSize;
    }

    //
    // 20220729
    //
    private void _fromFirebase()
    {
        if( _srcItem == null ) return ;
        final ProgressDialog pDlg = ProgressDialog.show( _activity , null , "下載中" , true , false );
        String path = _srcItem.getFirebaseBitmapPath() ;//"images/"+"imgName";
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        StorageReference photoReference= storageReference.child( path );

        final long ONE_MEGABYTE = 1024 * 1024 * 10;
        photoReference.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                _imageView.setImageBitmap(bmp);
                _imageView.setVisibility(View.VISIBLE);
                pDlg.dismiss();

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
        //        Toast.makeText(getApplicationContext(), "No Such file or Path found!!", Toast.LENGTH_LONG).show();
                pDlg.dismiss();
            }
        });

    }

}
