package com.my.notebook.myapplication;

import java.util.HashMap;
import java.util.Map;

public class MyUser
{
    public String uid = "" ; // firebase UID
    public String user = "" ; // 帳號
    public String name = "" ; // 暱稱
    public int salary = 0 ; // 月收入
    public String profession = "" ; // 職位
    public int budget = 0 ; // 預算

    public MyUser()
    {

    }


    public MyUser( MyUser userData )
    {
        uid = userData.uid ;
        user = userData.user;
        name = userData.name;
        salary = userData.salary;
        profession = userData.profession;
        budget = userData.budget;
    }

    void reset()
    {
        uid = "" ;
        user = "" ;
        name = "" ;
        salary = 0 ;
        profession = "" ;
        budget = 0 ;
    }

    public HashMap<String,Object> toMap()
    {
        HashMap<String,Object> ret = new HashMap<String,Object>();
        ret.put( "uid" , uid );
        ret.put( "user" , user );
        ret.put( "name" , name );
        ret.put( "salary" , salary );
        ret.put( "profession" , profession );
        ret.put( "budget" , budget );
        return ret ;
    }

    public String get( Map<String, Object> map , String key , String defStr )
    {
        try
        {
            defStr = map.get( key ).toString();
        }catch ( Exception e )
        {
            e.printStackTrace();
        }
        return defStr ;
    }

    public int get( Map<String, Object> map , String key , int  defInt )
    {
        try
        {
            defInt = Integer.parseInt( map.get( key ).toString());
        }catch ( Exception e )
        {
            e.printStackTrace();
        }
        return defInt ;
    }

    public void fromMap( Map<String, Object> data )
    {
        name = get( data , "name" , name ) ;
        salary = get( data , "salary" , salary ) ;
        profession = get( data , "profession" , profession ) ;
        budget = get( data , "budget" , budget ) ;
    }
}
