package com.my.notebook.myapplication.ui.main.result;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.my.notebook.myapplication.MyData;
import com.my.notebook.myapplication.R;

import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class result4 extends Fragment {

    private MyData _data ;

    private String Msg = "";
    private int Img = 0;

    private Handler handler = new Handler();

    public result4( MyData data ) {
        // Required empty public constructor
        super();
        _data = data;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View v = inflater.inflate(R.layout.fragment_result4, container, false);

        try {
            //創建OkHttpClient
            OkHttpClient client = new OkHttpClient().newBuilder().connectTimeout(500, TimeUnit.MILLISECONDS).build();
            //放入要POST的參數
            FormBody formBody = new FormBody.Builder()
                    .add("uid", _data.getUID())
                    .build();
            //建立request
            Request request = new Request.Builder()
                    .post(formBody)
                    .url(_data._url + "/result4")//flask server網址
                    .build();
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    //建立call
                    Call call = client.newCall(request);
                    try {
                        Response response = call.execute();
                        int responseData = Integer.parseInt(response.body().string());
                        switch (responseData){
                            case 1:
                                Msg = "恭喜達成\n朝自己的目標更進一步";
                                Img = R.drawable.win;
                                break;
                            case 2:
                                Msg = "可惜沒達標\n再接再厲吧";
                                Img = R.drawable.fail;
                                break;
                            default:
                                Msg = "查無目標\n新增一個目標，追求夢想吧";
                                Img = R.drawable.nothing;
                        }
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                setText(R.id.msg4,Msg,v);
                                setImg(R.id.img4,Img,v);
                            }
                        });

                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            t.start();
            try {
                Thread.sleep(500);
                t.interrupt();
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }catch ( Exception e ){
            e.printStackTrace();
        }

        return v;
    }

    //文字元件指向與資訊擺放
    private void setText( int id , String txt , View view )
    {
        try
        {
            TextView tv;
            tv = view.findViewById( id );
            tv.setText( txt );
        }catch ( Exception e )
        {
            e.printStackTrace();
        }
    }

    //圖片元件指向與資訊擺放
    private void setImg( int id , int img , View view )
    {
        try
        {
            ImageView iv;
            iv = view.findViewById( id );
            iv.setImageResource(img);
        }catch ( Exception e )
        {
            e.printStackTrace();
        }
    }
}