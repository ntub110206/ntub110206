package com.my.notebook.myapplication.ui.main;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.my.notebook.myapplication.MyData;
import com.my.notebook.myapplication.R;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class BucketPage extends Fragment
    implements FragmentInterface
{

    private MyData _data ;
    private View _root ;
    private View _add = null;

    private Button AddTargbtn, Completebtn, Quitbtn;
    private ProgressBar circlepg;
    private TextView pgtxt, TarView;
    //Dialog內的元件
    private EditText Target, TarMoney, TarPart;
    private Spinner tradeSpinner, detailSpinner;
    private ArrayAdapter tradeAdapter ;

    int tarSarplus = 0;

    private Handler handler = new Handler();

    public BucketPage( MyData data ) {
        super();
        _data = data;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        final View v  = _root = inflater.inflate(R.layout.fragment_main_bucket_page, container, false);
        upDate();

        circlepg = v.findViewById(R.id.pgb);
        Quitbtn = v.findViewById(R.id.quitButton);
        Completebtn = v.findViewById(R.id.completeButton);
        pgtxt = v.findViewById(R.id.progress_text);
        AddTargbtn = v.findViewById(R.id.addTarget);
        TarView = v.findViewById(R.id.tarView);

        AddTargbtn.setOnClickListener(new View.OnClickListener() {   //新增目標
            @Override
            public void onClick(View view) {
                Thread t = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                View v = _add = inflater.inflate(R.layout.view_add_bucket, null, false);

                                Target = v.findViewById(R.id.Target);
                                TarMoney = v.findViewById(R.id.TarMoney);
                                TarPart = v.findViewById(R.id.tarPart);
                                tradeSpinner = v.findViewById(R.id.id_target_spinner);
                                detailSpinner = v.findViewById(R.id.id_target_child_spinner);

                                tradeAdapter = new ArrayAdapter(
                                        getContext() , android.R.layout.simple_dropdown_item_1line ,
                                        MyData.mode1 );

                                tradeSpinner.setAdapter(tradeAdapter);

                                tradeSpinner.setOnItemSelectedListener(new ProvOnItemSelectedListener());
                                new AlertDialog.Builder(getContext())
                                        .setView(v)
                                        .setTitle("新增目標")
                                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                try{
                                                    String target = Target.getText().toString();
                                                    int mm = Integer.parseInt(TarMoney.getText().toString());
                                                    int pp = Integer.parseInt(TarPart.getText().toString());
                                                    String a = tradeSpinner.getSelectedItem().toString();
                                                    String b = detailSpinner.getSelectedItem().toString();
                                                    _data.flaskBucketAdd(null, view, target, a, b, mm, pp);
                                                }catch (Exception e){
                                                    e.printStackTrace();
                                                }
                                            }
                                        })
                                        .setOnDismissListener(new DialogInterface.OnDismissListener() {
                                            @Override
                                            public void onDismiss(DialogInterface dialogInterface) {_add = null;}
                                        })
                                        .setNegativeButton(android.R.string.no, null)
                                        .show();
                            }
                        });
                        try{
                            Thread.sleep(500);
                        }catch (InterruptedException e)
                        {
                            e.printStackTrace();
                        }
                    }
                });
                t.start();
                try {
                    Thread.sleep(500);
                    t.interrupt();
                }catch (InterruptedException e){
                    e.printStackTrace();
                }
            }
        });

        Quitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                _data.flaskBucketQuit();
            }
        });

        Completebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    //創建OkHttpClient
                    OkHttpClient client = new OkHttpClient().newBuilder().connectTimeout(500, TimeUnit.MILLISECONDS).build();
                    //放入要POST的參數
                    FormBody formBody = new FormBody.Builder()
                            .add("uid", _data.getUID())
                            .build();
                    //建立request
                    Request request = new Request.Builder()
                            .post(formBody)
                            .url(_data._url + "/bucketComplete")//flask server網址
                            .build();
                    Thread t = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            //建立call
                            Call call = client.newCall(request);
                            try {
                                Response response = call.execute();
                                String responseData = response.body().string();
                                String[] data = responseData.split(",");
                                String a = data[0];
                                String b = data[1];
                                int mm = Integer.parseInt(data[2]);
                                _data.flaskAccountAdd(null,view,a,b,mm);
                            }catch (Exception e){
                                e.printStackTrace();
                            }
                        }
                    });
                    t.start();
                    try {
                        Thread.sleep(500);
                        t.interrupt();
                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }
                }catch ( Exception e ){
                    e.printStackTrace();
                }
            }
        });

        return v;
    }

    @Override
    public void upDate() {

        try {
            if(_data.isLogin()) {
                //創建OkHttpClient
                OkHttpClient client = new OkHttpClient().newBuilder().build();
                //放入要POST的參數
                FormBody formBody = new FormBody.Builder()
                        .add("uid", _data.getUID())
                        .build();
                //建立request
                Request request = new Request.Builder()
                        .post(formBody)
                        .url(_data._url + "/getBucket")//flask server網址
                        .build();
                Thread t = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        //建立call
                        Call call = client.newCall(request);
                        try {
                            //取得回傳資訊
                            Response response = call.execute();
                            String responseData = response.body().string();
                            String[] data = responseData.split(",");
                            //轉換資料型態
                            String target = data[0];
                            int tarMoney = Integer.parseInt(data[1]);
                            if (tarSarplus > tarMoney)
                                tarSarplus = tarMoney;
                            else
                                tarSarplus = Integer.parseInt(data[2]);
                            Boolean check = Boolean.parseBoolean(data[3]);
                            int remain = Integer.parseInt(data[4]);
                            String pgTxt = String.format("%d/%d", tarSarplus, tarMoney);

                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    //元件指向與資訊擺放
                                    setText(R.id.tarView, target, _root);
                                    setProgress(R.id.pgb, tarMoney, tarSarplus, _root);


                                    if (check == true) {
                                        setBtn(R.id.addTarget, false, _root);
                                        if (tarMoney <= tarSarplus) {
                                            setText(R.id.progress_text, "本月目標完成", _root);
                                            if (remain <= 1) {
                                                setBtn(R.id.completeButton, true, _root);
                                                setBtn(R.id.quitButton, false, _root);
                                            } else {
                                                setBtn(R.id.completeButton, false, _root);
                                                setBtn(R.id.quitButton, false, _root);
                                            }
                                        } else {
                                            setText(R.id.progress_text, pgTxt, _root);
                                            setBtn(R.id.completeButton, false, _root);
                                            setBtn(R.id.quitButton, true, _root);
                                        }
                                    } else {
                                        setText(R.id.progress_text, "無目標", _root);
                                        setBtn(R.id.addTarget, true, _root);
                                        setBtn(R.id.completeButton, false, _root);
                                        setBtn(R.id.quitButton, false, _root);
                                    }
                                }
                            });

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                t.start();
                try {
                    Thread.sleep(500);
                    t.interrupt();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }catch ( Exception e ){
            e.printStackTrace();
        }
    }

    private class ProvOnItemSelectedListener implements OnItemSelectedListener, AdapterView.OnItemClickListener {

        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            long sel = tradeSpinner.getSelectedItemId();
            String item[] = MyData.getItem( sel );

            ArrayAdapter adapter = new ArrayAdapter(
                    getContext() , android.R.layout.simple_dropdown_item_1line , item);

            detailSpinner.setAdapter( adapter );
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {

        }

        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

        }
    }

    //文字元件指向與資訊擺放
    private void setText( int id , String txt , View view )
    {
        try
        {
            TextView tv;
            tv = view.findViewById( id );
            tv.setText( txt );
        }catch ( Exception e )
        {
            e.printStackTrace();
        }
    }

    //進度條元件指向與資訊擺放
    private void setProgress( int id , int max , int prog , View view )
    {
        try {
            ProgressBar cpg;
            cpg = view.findViewById(id);
            cpg.setMax(max);
            cpg.setProgress(prog);
        }catch ( Exception e ){
            e.printStackTrace();
        }
    }

    //按鈕元件指向
    private void setBtn( int id , Boolean vis , View view )
    {
        try {
            Button btn;
            btn = view.findViewById(id);
            if(vis == true)
                btn.setVisibility(View.VISIBLE);
            else if(vis == false)
                btn.setVisibility(View.INVISIBLE);
        }catch ( Exception e ){
            e.printStackTrace();
        }
    }
}