package com.my.notebook.myapplication;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
//import androidx.navigation.ui.AppBarConfiguration;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.my.notebook.myapplication.databinding.ActivityMainBinding;
import com.my.notebook.myapplication.ui.main.SectionsPagerAdapter;

import java.util.Calendar;



public class MainActivity extends AppCompatActivity
    implements MyData.MyDataListen
{

    private final MainActivity THIS = this ;
    private MyData _data ;//= new MyData();

 //   private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainBinding binding;
    private DrawerLayout _drawerLayout ;
    private  ViewPager _viewPager ;

    private View _root ;
    private NavigationView _navigationView ;

    SectionsPagerAdapter _pager ;



    //
    //
    private MyAddView _addView = null ;
   // @RequiresApi(api = Build.VERSION_CODES.R)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this._data = new MyData( THIS , this , _callCloudListener );
        _root = getLayoutInflater().inflate( R.layout.activity_body , null );
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView( binding.getRoot());

        SectionsPagerAdapter sectionsPagerAdapter = _pager = new SectionsPagerAdapter(this, getSupportFragmentManager() , _data );
        /*
        ViewPager viewPager = binding.viewPager;
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = binding.tabs;
        tabs.setupWithViewPager(viewPager);


        FloatingActionButton fab = binding.fab ;

        fab.setOnClickListener( _onAddData );

         */
        //

        LinearLayout ll = findViewById(R.id.main_root );
        ll.addView( _root );
        _root.findViewById( R.id.fab ).setOnClickListener( _onAddData );


        ViewPager viewPager = _viewPager = _root.findViewById( R.id.view_pager );
        viewPager.setAdapter(sectionsPagerAdapter);

        /*
        TabLayout tabs = binding.tabs;
        tabs.setupWithViewPager(viewPager);


        FloatingActionButton fab = binding.fab ;

        fab.setOnClickListener( _onAddData );
*/
        _navigationView = binding.navView;


        DrawerLayout drawer = _drawerLayout = binding.drawerLayout;


        ActionBarDrawerToggle drawerToggle = new ActionBarDrawerToggle(
                this,
                drawer,
                _root.findViewById( R.id.tb_main_toolbar ),
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close) {

            @Override
            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
             //   getActionBar().setTitle("mTitle");
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                initHeaderPage();
                // 按鈕

                boolean isLogin = _data.isLogin();
                View vv ;
                vv = _navigationView.findViewById( R.id.nav_item0 );
                vv.setEnabled( isLogin );
                vv.setOnClickListener( _navOnClickListener );

                vv = _navigationView.findViewById( R.id.nav_item1 );
                vv.setEnabled( isLogin );
                vv.setOnClickListener( _navOnClickListener );

                vv = _navigationView.findViewById( R.id.nav_item2 );
                vv.setEnabled( isLogin );
                vv.setOnClickListener( _navOnClickListener );

                vv = _navigationView.findViewById( R.id.nav_item3 );
                vv.setEnabled( isLogin );
                vv.setOnClickListener( _navOnClickListener );

                vv = _navigationView.findViewById( R.id.nav_item4 );
                vv.setEnabled( isLogin );
                vv.setOnClickListener( _navOnClickListener );

                vv = _navigationView.findViewById( R.id.nav_item5 );
                vv.setEnabled( isLogin );
                vv.setOnClickListener( _navOnClickListener );

                vv = _navigationView.findViewById( R.id.nav_item6 );
                vv.setEnabled( isLogin );
                vv.setOnClickListener( _navOnClickListener );
                //
          //      if( _data.isLogin()) //
            //    getActionBar().setTitle("mDrawerTitle");
            }
        };

        drawerToggle.syncState();

   //     drawerToggle.clo
        drawer.setDrawerListener(drawerToggle);

        _data.getValue();

        //result頁面

    }

    //
    //

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    //
    // 更新頭像
    private void initHeaderPage()
    {
        TextView tv ;
        String user = "訪客" ;
        String email = "" ;
        if( _data.isLogin())
        {
            MyUser userData = _data.getUser();
            user = userData.name ;
            email = userData.user ;
        }
        //
        //
        try
        {
            tv = _navigationView.findViewById( R.id.tv_username );
            tv.setText( user );
            tv = _navigationView.findViewById( R.id.tv_email );
            tv.setText( email );
        }catch ( Exception e )
        {
            e.printStackTrace();
        }


    }
    //
    //
    @Override
    public void MyDataListen_OnPermissions()
    {
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        //
        /*
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if(!Environment.isExternalStorageManager()){
                Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                startActivity(intent);
                return;
            }
        }*/
    }
    //
    private final MyData.CallCloudListener _callCloudListener = new MyData.CallCloudListener()
    {
        @Override
        public void onReturn( boolean isOk, Object inData )
        {
            try {
                _pager.upDate2();
                // 更新頭像
                THIS.initHeaderPage();
            }catch ( Exception e ){
                e.printStackTrace();
            }
        }
    };
    //
    // TODO: 20220729
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode , resultCode , data);
        if( _addView == null )
            return ;

    }
    //
    // 新增
    private final View.OnClickListener _onAddData = new View.OnClickListener()
    {
        @Override
        public void onClick(View view)
        {
            MyDataListen_OnAdd( null );
        }
    };

    //
    //
    @Override
    public void MyDataListen_OnAdd( Calendar cal )
    {
        if( _data.noLogin())
        {

            Snackbar.make( _root , "沒有登入", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
            return ;
        }
        // 下訊息
            /*
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();*/

        MyAddView v = _addView = new MyAddView( THIS , _data , null ) ;

        new AlertDialog.Builder(THIS)
                .setView( v )
                .setTitle("新增")
                //     .setMessage("Are you sure you want to delete this entry?")

                // 確定鈕
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which)
                    {
                        v.Save( binding.getRoot() , cal );
                        _addView = null ;
                    }
                })
                // 關閉
                .setOnDismissListener( new DialogInterface.OnDismissListener()
                {
                    @Override
                    public void onDismiss( DialogInterface dialogInterface )
                    {
                        _addView = null ;
                    }
                } )
                // 取消鈕
                .setNegativeButton(android.R.string.no, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    @Override
    public void MyDataListen_OnDel( MyData.ITEM item )
    {

        new AlertDialog.Builder(THIS)
               .setMessage( item._src )
                .setTitle("移除")
                //     .setMessage("Are you sure you want to delete this entry?")

                // Specifying a listener allows you to take an action before dismissing the dialog.
                // The dialog is automatically dismissed when a dialog button is clicked.
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which)
                    {
                        _data.budgetCalculateAfterRemove( item );
                        _data.delItem( item );
                    }
                })

                // A null listener allows the button to dismiss the dialog and take no further action.
                .setNegativeButton(android.R.string.no, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    // TODO: 20220718
    @Override
    public void MyDataListen_OnUpdate( MyData.ITEM item )
    {
        if( _data.noLogin())
        {
            Snackbar.make( _root , "沒有登入", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
            return ;
        }

        Calendar cal = Calendar.getInstance();
        cal.set( item.yy , item.mon -1 , item.dd , item.hh , item.mm);
        // TODO: 20220718
        MyAddView v = _addView = new MyAddView( THIS , _data , item ) ;

        new AlertDialog.Builder(THIS)
                .setView( v )
                .setTitle("修改")

                // 確定鈕
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which)
                    {
                        v.Save( binding.getRoot() , cal );
                        _addView = null ;
                    }
                })
                // 關閉
                .setOnDismissListener( new DialogInterface.OnDismissListener()
                {
                    @Override
                    public void onDismiss( DialogInterface dialogInterface )
                    {
                        _addView = null ;
                    }
                } )
                // 取消鈕
                .setNegativeButton(android.R.string.no, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();

    }

    private final View.OnClickListener _navOnClickListener = new View.OnClickListener()
    {
        @Override
        public void onClick(View v) {
            try {
                int id = v.getId();
                if (id == R.id.nav_item0) {
                    _viewPager.setCurrentItem(0);
                } else if (id == R.id.nav_item1) {
                    _viewPager.setCurrentItem(1);
                } else if (id == R.id.nav_item5) {
                    _viewPager.setCurrentItem(2);
                }else if (id == R.id.nav_item6) {
                    _viewPager.setCurrentItem(3);
                } else if (id == R.id.nav_item2) {
                    _viewPager.setCurrentItem(4);
                } else if (id == R.id.nav_item4) {
                    _viewPager.setCurrentItem(5);
                } else if (id == R.id.nav_item3) {
                    _data.logoutUser(_onFirebaseCallback, 0);
                    _viewPager.setCurrentItem(0);
                }
                _drawerLayout.closeDrawers();
                ;
                //    _navigationView.setVisibility( View.GONE );
            }catch ( Exception e ){
                e.printStackTrace();
            }
        }
    };

    private final MyData.CallCloudListener _onFirebaseCallback = new MyData.CallCloudListener()
    {

        @Override
        public void onReturn( boolean isOk, Object inData )
        {
            _viewPager.setCurrentItem( 0 );
        }
    };
    //
    // TODO: 20220729
    @Override
    public void MyDataListen_OnMessage( String msg )
    {
        Snackbar.make( _root , msg , Snackbar.LENGTH_LONG ).setAction( "Action", null ).show();

    }



    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // 在發生onRestoreInstanceState之後同步切換狀態
   //     mDrawerToggle.syncState();
    }

    //系統設定改變時觸發
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
   //     mDrawerToggle.onConfigurationChanged(newConfig);
    }

    //按下任意ActionBar選單時觸發
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // 如果ActionBarDrawerToggle的onOptionItemSelected回傳true，
        // 則處理App Icon 點擊事件
    //    if (mDrawerToggle.onOptionsItemSelected(item)) {
     //       return true;
    //    }
        return super.onOptionsItemSelected(item);
    }

}