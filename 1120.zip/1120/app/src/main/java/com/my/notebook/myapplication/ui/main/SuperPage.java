package com.my.notebook.myapplication.ui.main;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.PieChart;
import com.my.notebook.myapplication.MyData;
import com.my.notebook.myapplication.MyUser;
import com.my.notebook.myapplication.R;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class SuperPage extends Fragment
        implements FragmentInterface
{
    private final SuperPage THIS= this ;
    private final MyData _data ;

    private View _root ;

    private Handler handler = new Handler();

    private Button btnUpdate;
    private EditText edtName, edtPro, edtSalary, edtBudget;


    public SuperPage( MyData data )
    {
        super();
        _data = data ;

    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {

        final View root = _root =inflater.inflate(R.layout.fragment_main_super_page, container, false);

        btnUpdate = root.findViewById(R.id.button_update);
        edtName = root.findViewById(R.id.my_name);
        edtPro = root.findViewById(R.id.my_profession);
        edtSalary = root.findViewById(R.id.my_salary);
        edtBudget = root.findViewById(R.id.my_budget);

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = edtName.getText().toString();
                String pro = edtPro.getText().toString();
                String salary = edtSalary.getText().toString();
                String budget = edtBudget.getText().toString();
                _data.flaskUserUpdate(name,pro,salary,budget,root);
            }
        });

     //   upDate();
        _data.getUserData( this._onFirebaseCallback );

        return root ;

    }

    @Override
    public void upDate()
    {
        //flask
        //創建OkHttpClient
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        //放入要POST的參數
        FormBody formBody = new FormBody.Builder()
                .add("uid", _data.getUID())
                .build();
        //建立request
        Request request = new Request.Builder()
                .post(formBody)
                .url(_data._url + "/getInfo")//flask server網址
                .build();
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                //建立call
                Call call = client.newCall(request);
                try {
                    //取得回傳資訊
                    Response response = call.execute();
                    String responseData = response.body().string();
                    //資訊字串分割
                    String[] data = responseData.split(",");
                    //轉換資料型態
                    String textUser   = data[0];
                    String textName   = data[1];
                    String textPro    = data[2];
                    String textbudget = data[3];
                    String textSalary = data[5];

                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            //元件指向與資訊擺放
                            setText(R.id.my_username, textUser);
                            setText(R.id.my_name, textName);
                            setText(R.id.my_profession, textPro);
                            setText(R.id.my_salary, textSalary);
                            setText(R.id.my_budget, textbudget);
                        }
                    });
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        });
        t.start();
        try {
            Thread.sleep(100);
            t.interrupt();
        }catch (InterruptedException e){
            e.printStackTrace();
        }
    }
    //
    private void setText( int id , Object text )
    {

        try
        {
            TextView tv;
            tv = _root.findViewById( id );
            tv.setText( text.toString() );
        }catch ( Exception e )
        {
            e.printStackTrace();
        }

    }

    //

    //
    private final MyData.CallCloudListener _onFirebaseCallback = new MyData.CallCloudListener()
    {

        @Override
        public void onReturn( boolean isOk, Object inData )
        {
            upDate();
        }
    };


    private String get( int id , String value )
    {
        try
        {
            TextView tv = _root.findViewById( id );
            value = tv.getText().toString();
        }catch ( Exception e )
        {
            e.printStackTrace();
        }
        return value ;
    }
    private int get( int id , int value )
    {
        try
        {
            TextView tv = _root.findViewById( id );
            value = Integer.parseInt( tv.getText().toString() );
        }catch ( Exception e )
        {
            e.printStackTrace();
        }
        return value ;

    };


}
