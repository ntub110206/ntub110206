package com.my.notebook.myapplication;
// firebase 專案名稱 111206
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.annotations.NotNull;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.my.notebook.myapplication.ui.main.BucketPage;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Handler;
import java.util.logging.LogRecord;

import androidx.annotation.NonNull;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MyData
{
    private final MyData THIS = this ;

    // firebase dir
    static private final String _ROOT_DIR = "users" ;

    private final Activity _activity ; // 主頁
    private final FirebaseAuth _auth = FirebaseAuth.getInstance(); // firebase 認證
    private FirebaseUser _user = null ; // user 資料
    private final MyUser _userData = new MyUser(); // 自定的 user 訊息
    private String _uid = "" ; // firebase 的user 編號
    private final List< ITEM> _items = new ArrayList<>(); // 目前已登記竹事項

//    private String _url = "http://140.131.114.157:5000"; // flask後端網址
    public String _url = "http://10.0.2.2:5000";   //flask測試網址

    private String _responseData;

    private final CallCloudListener _callCloudListener ;
    //
    //
    int _index = 0 ;
    //
    private final MyDataListen _listener;

    // firebase 執行結束的訊息
    public interface CallCloudListener
    {
        public void onReturn(  boolean isOk , Object inData );
    };

    // 處理記帳事項的界面
    public interface MyDataListen
    {
        public void MyDataListen_OnAdd( Calendar cal ); // 新增
        public void MyDataListen_OnDel( ITEM item ); // 移除
        // TODO: 20220718
        public void MyDataListen_OnUpdate( ITEM item );  // 更新
        // TODO: 20220729
        public void MyDataListen_OnMessage( String msg ); // 訊息
        public void MyDataListen_OnPermissions(); // 認證

    }



    //
    // 總數
    public class TOTAL
    {
        public final String _name ; // 大項名稱
        public final int _totalMoney ; // 總金額
        public final float _pi ; // 比例
        public TOTAL( String name , int totalMoney , float pi )
        {
            _name = name ;
            _totalMoney = totalMoney ;
            _pi = pi ;
        }
    }
    //
    // 年月日事項列表
    public class DATA_YYMMDD
    {
        public final int _yy ; // 年
        public final int _mm ; // 月
        public final int _dd ; // 日，非必要
        public int inMon = 0 ; // 總收入
        public int outMon = 0 ; // 總支出

        private final List<ITEM> _buf = new ArrayList<>(); // 當天消費項目

        DATA_YYMMDD( int yy , int mm , int dd )
        {
            _yy = yy ;
            _mm = mm ;
            _dd = dd ;
        }

        DATA_YYMMDD()
        {
            Calendar cal = Calendar.getInstance();
            _yy = cal.get( Calendar.YEAR );
            _mm = cal.get( Calendar.MONTH ) + 1 ;
            _dd = cal.get( Calendar.DAY_OF_MONTH );
        }


        public void add( ITEM item )
        {
            _buf.add( item );

        }

        public boolean check( int yy, int mm , int dd )
        {
            if( _dd == dd )
                if( _yy == yy )
                    return _mm == mm ;
            return false ;
        }
        public boolean check( int yy, int mm  )
        {
            if( _yy == yy )
                return _mm == mm ;
            return false ;
        }
        //
        public Calendar toCalender()
        {
            Calendar ret = Calendar.getInstance();
            ret.set( Calendar.YEAR , _yy );
            ret.set( Calendar.MONTH , _mm -1 );
            ret.set( Calendar.DAY_OF_MONTH , _dd );
            return ret ;
        }

        //
        //
        public void Build()
        {
            outMon = inMon = 0 ;
            for( ITEM ii : _buf )
            {
                if( ii.isOut())
                    outMon += ii.money ;
                else
                    inMon += ii.money ;
            }
        }
        //
        @Override
        public String toString()
        {
            if( _buf.size() == 0 )
                return " - 沒有資料 - " ;

            return "\n"
                    + "收入：" + inMon + "\n"
                    + "支出：" + outMon + "\n"
                    + "結算：" + ( inMon - outMon ) + "\n"
                    ;
        }

        public boolean isEmpty()
        {
            return _buf.isEmpty();
        }

        //
        public Object toString( int salary )
        {
            if( _buf.size() == 0 )
                return " - 沒有資料 - " ;
            final int mon = salary + inMon ;
            return "\n"
                    + "固定收入：" + salary + "\n"
                    + "額外收入：" + inMon + "\n"
                    + "本月收入：" + mon + "\n"
                    + "本月支出：" + outMon + "\n"
                    + "本月結算：" + ( mon - outMon ) + "\n"
                    ;

        }

        public ITEM[] getBuf()
        {
            return _buf.toArray( new ITEM[_buf.size()]) ;
        }
    }
    //

    //
	// 單項
    public class ITEM
    {
        final public String _firebaseId ;
        final public String A ; // 大項
        final public String B ; // 小項
        final public int money ; // 金額
        final public int yy ; // 年
        final public int mon ; // 月
        final public int dd ; // 日
        final public int hh ; // 時
        final public int mm ; // 分
        final public String _src ; // 資料
        final private String [] _split; // 分割後

        ITEM( String firebaseId , String str ) throws Exception
        {


            _firebaseId = firebaseId ;
            _split = str.split( "\t" );
            _src = str ;
            A = _split[1] ;
            B = _split[2] ;
            money = Integer.parseInt( _split[3] );
            String [] ssa = _split[0].split( " " );
            String [] ss = ssa[0].split( "/"  );

            yy = Integer.parseInt( ss[0] );
            mon = Integer.parseInt( ss[1] );
            dd = Integer.parseInt( ss[2] );

            String [] ss2 = ssa[1].split( ":" );
            hh = Integer.parseInt( ss2[0] );
            mm = Integer.parseInt( ss2[1] );

        }


        public ITEM( String _firebaseId, String a, String b, int money, int yy, int mon, int dd, int hh, int mm, String _src, String[] _split )
        {

            this._firebaseId = _firebaseId;
            this.A = a;
            this.B = b;
            this.money = money;
            this.yy = yy;
            this.mon = mon;
            this.dd = dd;
            this.hh = hh;
            this.mm = mm;
            this._src = _src;
            this._split = _split;
        }

        public ITEM( ITEM src ) throws Exception
        {

            this._firebaseId = src._firebaseId;
            this.A = src.A;
            this.B = src.B;
            this.money = src.money;
            this.yy = src.yy;
            this.mon = src.mon;
            this.dd = src.dd;
            this.hh = src.hh;
            this.mm =src. mm;
            this._src = src._src;
            this._split = src._split;
        }


        @Override
        public String toString()
        {
            return String.format( "%s %s %d" , A , B , money );
        }

        public int indexOf( String str )
        {
            return _src.indexOf( str );
        }

        public int aIndex()
        {
            int i = -1;
            try
            {
                for( i = 0 ; i < mode.length ; ++i )
                    if( A.equals( mode[i] )) {}
            }catch( Exception e )
            {
                e.printStackTrace();
            }
            return i ;
        }
        public int bIndex()
        {
            int i = -1;
            try
            {
                String[] mm = mode2[aIndex()] ;
                for( i = 0 ; i < mm.length ; ++i )
                    if( B.equals( mm[i] )) {}
            }catch( Exception e )
            {
                e.printStackTrace();
            }
            return i;
        }
        //
        //
        public String getFirebaseBitmapPath()
        {
            return getBitmapPath( _firebaseId );
        }

        public boolean isOut() {
            return aIndex() != ( mode.length - 1 ) ;
        }

        public Map<String,Object> toJson()
        {
            HashMap<String,Object> map = new HashMap<>();
            map.put( "data" , _src );
            map.put( "date" , String.format( "%d/%d/%d"
                    , this.yy , this.mon , this.dd
            ));

            map.put( "year" , this.yy );
            map.put( "month" , this.mon );
            map.put( "tradeType" , this.A );
            map.put( "detail" , this.B );
            map.put( "money" , this.money );
            return map ;
        }
    }



    public static final String FILD_NAME = "MyData_DATA" ;

    public static final String mode[]         = new String[]{  "食","衣","行" , "育", "樂" , "月結 " , "額外收入" , } ;

    public static final String mode1[]        = new String[]{  "食","衣","行" , "育", "樂" , "月結 " , } ;

    public static final String mode_in_item[] = new String[]{"月薪","獎金" , "意外" } ;

    public static final String mode0_item[]   = new String[]{"自煮" , "餐館","飲料" } ;

    public static final String mode1_item[]   = new String[]{"外出服" , "休閒服" , "鞋" , "包"} ;

    public static final String mode2_item[]   = new String[]{"加油" , "計程車" , "大眾運輸" , "高鐵"} ;

    public static final String mode3_item[]   = new String[]{ "學費" , "補習費" , "參考書"} ;

    public static final String mode4_item[]   = new String[]{"遊戲" , "電影" , "景點" , "紅包"} ;

    public static final String mode5_item[]   = new String[]{"水費" , "電費" , "通信" } ;

    public static final String[] mode2 [] =
            {
                    mode0_item ,
                    mode1_item ,
                    mode2_item ,
                    mode3_item ,
                    mode4_item ,
                    mode5_item ,

                    mode_in_item , // 7

            };


    public static String[] getItem( long sel )
    {
        if( sel >= 0 )if( sel < mode2.length )
            return mode2[(int)sel] ;
        return new String[0] ;
        /*
        String ret[] = mode0_item ;
        if( sel == 1 )
            ret = MyData.mode1_item ;
        else if( sel == 2 )
            ret =  MyData.mode2_item ;
        else if( sel == 3 )
            ret =  MyData.mode3_item ;
        else if( sel == 4 )
            ret =  MyData.mode4_item ;
        else if( sel == 5 )
            ret =  MyData.mode5_item ;
        return ret ;*/
    }



    public MyData( Activity activity ,  MyDataListen listener , CallCloudListener callCloudListener  )
    {
        _callCloudListener = callCloudListener ;
        _activity = activity ;
        _listener = listener ;

        _user = _auth.getCurrentUser();
        getUserData( null );

/*
        SharedPreferences sp = context.getSharedPreferences( FILD_NAME , Context.MODE_PRIVATE );
        Set<String> set = sp.getStringSet( "SET" , new HashSet<String>() );
        _set.addAll( set );
        _index = _set.size() ;

 */
    }

    //
    //
    public static boolean checkYYMMDD( Calendar a , Calendar b )
    {
        if( a.get( Calendar.YEAR ) == b.get( Calendar.YEAR ))
            if( a.get( Calendar.MONTH ) == b.get( Calendar.MONTH ))
                if( a.get( Calendar.DAY_OF_MONTH ) == b.get( Calendar.DAY_OF_MONTH ))
                    return true ;
        return false ;
    }
    // get
    public ITEM[] getItem()
    {
        ArrayList<ITEM> list = new ArrayList<>();
        for( final ITEM s : _items )
        {
            try
            {
                list.add( new ITEM( s ) );
            }catch ( Exception e )
            {
                e.printStackTrace();
            }

        }

        return list.toArray( new ITEM[list.size()]) ;
    }

    // get
    public ITEM[] getItem( int yy , int mm , int dd )
    {
        String str = String.format( "%04d/%02d/%02d " , yy , mm , dd );
        ArrayList<ITEM> list = new ArrayList<>();
        for( final ITEM s : _items )
        {

            try
            {
                if( s.indexOf( str  ) != 0 )
                    continue;
                list.add( new ITEM( s ) );
            }catch ( Exception e )
            {
                e.printStackTrace();
            }

        }

        return list.toArray( new ITEM[list.size()]) ;
    }

    //
    static public int modeIndex( String name )
    {
        int i ;
        for( i = 0 ; i < mode.length ; ++i  )
            if( mode[i].compareTo( name ) == 0 )
            {
                return i ;
            }
        return -1 ;
    }
    //
    // 計算各項目加總
    public TOTAL[] getTotal()
    {
        int i ;
        TOTAL[] ret = new TOTAL[mode.length] ;
        int mon[] = new int[mode.length] ;
        int total = 0 ;
        ITEM[] item = getItem() ;
        for( ITEM ii : item )
        {
            try
            {
                int index = modeIndex( ii.A );
                mon[index] += ii.money ;
                total +=  ii.money ;
            } catch ( Exception e )
            {
                e.printStackTrace();
            }
        }

        if( total == 0 )
            total = 1 ;
        for( i = 0 ; i < ret.length ; ++i )
            ret[i] = new TOTAL( mode[i] , mon[i] , (float)mon[i] / (float)total );
        return ret ;

    }


    // 計算指定年月，各項目加總
    public TOTAL[] getTotal( int YY , int MM )
    {
        int i ;
        TOTAL[] ret = new TOTAL[mode.length] ;
        int mon[] = new int[mode.length] ;
        int total = 0 ;
        DATA_YYMMDD yymm = getThisMonth( YY , MM );
        ITEM[] item = yymm.getBuf();
        for( ITEM ii : item )
        {
            try
            {
                int index = modeIndex( ii.A );
                mon[index] += ii.money ;
                total +=  ii.money ;
            } catch ( Exception e )
            {
                e.printStackTrace();
            }
        }

        if( total == 0 )
            total = 1 ;
        for( i = 0 ; i < ret.length ; ++i )
            ret[i] = new TOTAL( mode[i] , mon[i] , (float)mon[i] / (float)total );
        return ret ;

    }

    //
    public void onAdd(  Calendar cal  )
    {
        _listener.MyDataListen_OnAdd( cal );
    }

    // 取得
    public DATA_YYMMDD[] getSet()
    {
        int i ;
        DATA_YYMMDD yymm = null;
        List<DATA_YYMMDD> ret = new ArrayList<>();
        ITEM[]items =  getItem() ;
        for( ITEM item : items )
        {
            for( i = 0 ; i < ret.size() ; ++i )
            {
                yymm = ret.get( i );
                if( yymm.check( item.yy , item.mon , item.dd ))
                    break ;
            }

            if( i == ret.size())
            {
                yymm = new DATA_YYMMDD( item.yy , item.mon , item.dd );
                ret.add( yymm  );
            }
            yymm.add( item );

        }

        for( DATA_YYMMDD ii : ret )
            ii.Build();
        return ret.toArray( new DATA_YYMMDD[ret.size()]) ;
    }
    // 取得這個月項目
    public DATA_YYMMDD getThisMonth()
    {
        int i ;
        DATA_YYMMDD yymm = new DATA_YYMMDD() ;
        ITEM[]items =  getItem() ;
        for( ITEM item : items )
        {

            if( yymm.check( item.yy , item.mon ))
                yymm.add( item );

        }

        yymm.Build();
        return yymm ;
    }

    // 取得這個月項目
    public DATA_YYMMDD getThisMonth( int YY , int MM )
    {
        int i ;
        DATA_YYMMDD yymm = new DATA_YYMMDD( YY , MM , 0 ) ;
        ITEM[]items =  getItem() ;
        for( ITEM item : items )
        {

            if( yymm.check( item.yy , item.mon ))
                yymm.add( item );

        }

        yymm.Build();
        return yymm ;
    }

    //
    //
    //
    public boolean noLogin()
    {
        return false == isLogin();
    }
    // 是否登人
    public boolean isLogin()
    {
        _user = _auth.getCurrentUser();
        if( _user == null )
            return false ;
        String uid = _auth.getUid() ;
        _userData.uid = _user.getEmail();
        return uid.length() > 0 ;
    }

    // 登入
    public void signUser( CallCloudListener listener , String user , String pass , final Object inData   )
    {
        _auth.signInWithEmailAndPassword(user, pass)
                .addOnCompleteListener( _activity, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task)
                    {
                        if (task.isSuccessful()) {
                            getUserData( listener );
                            getValue();
                            _user = _auth.getCurrentUser();
                            Toast.makeText( _activity, "success", Toast.LENGTH_SHORT).show();
                        } else {

                            Toast.makeText( _activity , task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            listener.onReturn( task.isSuccessful() , inData );
                        }
                    }
                });
    }
    // 登出
    public void logoutUser( CallCloudListener listener , final Object inData )
    {
        FirebaseAuth.getInstance().signOut();
        _items.clear();
        _callCloudListener.onReturn( true , this );
        listener.onReturn( true , inData );
    }

    // 註冊
    public void createUser( CallCloudListener listener , String user , String pass , final Object inData  )
    {
        _auth.createUserWithEmailAndPassword(user, pass)
                .addOnCompleteListener( _activity, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task)
                    {

                        _items.clear();
                        _user = _auth.getCurrentUser() ;
                        if (task.isSuccessful())
                        {
                            getValue( );
                            setUser( listener ,  _userData );
                        } else
                        {

                            listener.onReturn( task.isSuccessful() , inData );
                            Toast.makeText( _activity , task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    //
    final private Set<String> _data = new HashSet<>();
    /*
    public Set<String> getData( CallCloudListener listener , Set<String> ret )
    {
        if( isLogin())
            ret.addAll( _data );
        return ret ;
    }*/

    //
    public String getUID()
    {
        return _auth.getUid();
    }
    // 取user資料
    public MyUser getUser()
    {
        if( noLogin() )
            return new MyUser();
        _userData.user = _auth.getCurrentUser().getEmail();
        return new MyUser( _userData );
    }

    public void getUserData( CallCloudListener listener)
    {
        try
        {

            userCollection().get().addOnCompleteListener( new OnCompleteListener<DocumentSnapshot>()
            {
                @Override
                public void onComplete( @NonNull Task<DocumentSnapshot> task )
                {
                    if( task.isSuccessful())
                    {
                        DocumentSnapshot doc = task.getResult() ;
                        _userData.fromMap( doc.getData());
                    };

                    if( listener != null )
                        listener.onReturn( task.isSuccessful() , _userData );
                }
            } );
        }catch ( Exception e )
        {
            e.printStackTrace();
        }

    }

    static public DocumentReference getFirebaseFirestore( String path )
    {
        return  FirebaseFirestore.getInstance().document( '/' + _ROOT_DIR + '/' + path );//
        //  return FirebaseFirestore.getInstance().collection( '/' + db_name + '/' + path ) ;
    }
    static public CollectionReference getFirebaseFirestore()
    {
        return FirebaseFirestore.getInstance().collection( _ROOT_DIR ) ;
    }

    public DocumentReference userCollection()
    {
        return getFirebaseFirestore( getUID());
    }
    //
    public boolean setUser( CallCloudListener listen , MyUser user )
    {
        boolean done = false;
        try
        {
            if( noLogin() )
                return done;
            String uid = getUID();
            _userData.user = _auth.getCurrentUser().getEmail();
            _userData.name = user.name;
            _userData.profession = user.profession;
            _userData.salary = user.salary;
            _userData.uid = uid;
            _userData.budget = user.budget ;

            getFirebaseFirestore().document( uid ).set( _userData.toMap() ).addOnCompleteListener( _activity, task ->
            {
                showToast( "setUser", task );
                if( listen != null )
                    listen.onReturn( task.isSuccessful(), user );
                    /*
                    final CollectionReference cc = doc.collection( "array" ) ;
                    for( final MyView.MDATA d : buf )
                    {
                        cc.add( d.getMap())
                                .addOnCompleteListener( ac, task1 ->
                                {

                                });
                    }*/

            } );

            done = true;
        }catch ( Exception e )
        {
            e.printStackTrace();
        }

        return done ;
    }
    //
    public void showToast( Object obj , Task<?> task )
    {

        try
        {
            String str = obj.toString() ;
            if( task.isSuccessful())
                str += " Successful" ;
            else
            {
                str += " error" ;

                if( task.getException() != null )
                    str += "\n" + task.getException().getMessage();
          }

            Toast.makeText( _activity, str, Toast.LENGTH_SHORT ).show();

        }catch ( Exception e )
        {
            e.printStackTrace();
        }

    }


    // 取得所有項目
    public void getValue()
    {
        try
        {
            _items.clear();
            if( isLogin() == false )
                throw new Exception( "沒有登入") ;

            //
            DocumentReference ref = userCollection();
            //
            ref.collection( "Account" ).get().addOnCompleteListener( new OnCompleteListener<QuerySnapshot>()
            {
                @Override
                public void onComplete( @NonNull Task<QuerySnapshot> task )
                {
                    if( task.isSuccessful())
                    {
                        QuerySnapshot qq = task.getResult();
                        List<DocumentSnapshot> list = qq.getDocuments();
                        for( DocumentSnapshot d : list )
                        {
                            try
                            {
                                _items.add( new ITEM( d.getId(), d.get( "data" ).toString() ) );

                            } catch ( Exception e )
                            {
                                e.printStackTrace();
                            }
                        }
                    }
                    _callCloudListener.onReturn(  task.isSuccessful() , THIS );
                }
            } );

        }catch ( Exception e )
        {
            e.printStackTrace();
            _callCloudListener.onReturn(  false , e.toString() );
        }
    }

    //flask變更用戶資料
    public void flaskUserUpdate( String name , String pro , String salary , String budget , View view )
    {
        try {
            //創建OkHttpClient
            OkHttpClient client = new OkHttpClient().newBuilder().connectTimeout(500, TimeUnit.MILLISECONDS).build();
            //放入要POST的參數
            FormBody formBody = new FormBody.Builder()
                    .add("uid", getUID())
                    .add("name",name)
                    .add("profession",pro)
                    .add("salary",salary)
                    .add("budget",budget)
                    .build();
            //建立request
            Request request = new Request.Builder()
                    .post(formBody)
                    .url(_url + "/userUpdate")//flask server網址
                    .build();
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    //建立call
                    Call call = client.newCall(request);
                    try {
                        Response response = call.execute();
                        _responseData = response.body().string();
                        _activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Snackbar.make(view, "完成", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                                _callCloudListener.onReturn( response.isSuccessful() , this );
                            }
                        });
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            t.start();
            try {
                Thread.sleep(1000);
                t.interrupt();
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }catch ( Exception e ){
            e.printStackTrace();
        }
    }

    //flask新增帳目
    public void flaskAccountAdd( Calendar calendar , View view , String a , String b , int money )
    {
        try {
            //檢查行事曆
            if (calendar == null)
                calendar = Calendar.getInstance();
            //行事曆物件定義
            int yy = calendar.get(Calendar.YEAR);
            int mon = calendar.get(Calendar.MONTH) + 1;
            int dd = calendar.get(Calendar.DAY_OF_MONTH);
            int hh = calendar.get( Calendar.HOUR_OF_DAY );
            int mm = calendar.get( Calendar.MINUTE );
            //資料型態轉換
            String date = String.format("%d/%d/%02d", yy, mon, dd);
            String year = String.format("%d", yy);
            String month = String.format("%02d", mon);
            String moneyValue = String.format("%d", money);

            final String ret = String.format( "%04d/%02d/%02d %02d:%02d\t%s\t%s\t%d", yy, mon, dd, hh, mm, a, b, money );
            Map<String, Object> map = new ITEM("", ret).toJson();

            //創建OkHttpClient
            OkHttpClient client = new OkHttpClient().newBuilder().connectTimeout(500, TimeUnit.MILLISECONDS).build();
            //放入要POST的參數
            FormBody formBody = new FormBody.Builder()
                    .add("uid", getUID())
                    .add("date", date)
                    .add("year", year)
                    .add("month", month)
                    .add("data", ret)
                    .add("title", a)
                    .add("detail", b)
                    .add("money", moneyValue)
                    .build();
            //建立request
            Request request = new Request.Builder()
                    .post(formBody)
                    .url(_url + "/accountAdd")//flask server網址
                    .build();
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    //建立call
                    Call call = client.newCall(request);
                    try {
                        Response response = call.execute();
                        _responseData = response.body().string();
                        String[] data = _responseData.split(",");
                        String resID     = data[0];
                        String resBudget = data[1];
                        _items.add(new ITEM(resID, ret));
                        _activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Snackbar.make(view, "完成\n資產餘額剩餘：" + resBudget, Snackbar.LENGTH_LONG).setAction("Action", null).show();
                                _callCloudListener.onReturn( response.isSuccessful() , this );
                            }
                        });
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            t.start();
            try {
                Thread.sleep(1000);
                t.interrupt();
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //flask變更帳目
    public void flaskAccountUpdate( Calendar calendar , View view , String a , String b , int money , final String firebaseId )
    {
        try{
            //檢查行事曆
            if (calendar == null)
                calendar = Calendar.getInstance();
            //行事曆物件定義
            int yy = calendar.get(Calendar.YEAR);
            int mon = calendar.get(Calendar.MONTH) + 1;
            int dd = calendar.get(Calendar.DAY_OF_MONTH);
            int hh = calendar.get( Calendar.HOUR_OF_DAY );
            int mm = calendar.get( Calendar.MINUTE );
            //資料型態轉換
            String date = String.format("%d/%d/%02d", yy, mon, dd);
            String year = String.format("%d", yy);
            String month = String.format("%02d", mon);
            String moneyValue = String.format("%d", money);

            final String ret = String.format( "%04d/%02d/%02d %02d:%02d\t%s\t%s\t%d", yy, mon, dd, hh, mm, a, b, money );
            Map<String, Object> map = new ITEM("", ret).toJson();

            //創建OkHttpClient
            OkHttpClient client = new OkHttpClient().newBuilder().connectTimeout(500, TimeUnit.MILLISECONDS).build();
            //放入要POST的參數
            FormBody formBody = new FormBody.Builder()
                    .add("uid", getUID())
                    .add("aid", firebaseId)
                    .add("date", date)
                    .add("year", year)
                    .add("month", month)
                    .add("data", ret)
                    .add("title", a)
                    .add("detail", b)
                    .add("money", moneyValue)
                    .build();
            //建立request
            Request request = new Request.Builder()
                    .post(formBody)
                    .url(_url + "/accountUpdate")//flask server網址
                    .build();
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    //建立call
                    Call call = client.newCall(request);
                    try {
                        Response response = call.execute();
                        _responseData = response.body().string();
                        String[] data = _responseData.split(",");
                        String resID     = data[0];
                        String resBudget = data[1];
                        for( ITEM item : _items )
                        {
                            if( item._firebaseId.equals( firebaseId ) )
                            {
                                _items.remove( item );
                                _items.add(new ITEM(resID, ret));
                                break;
                            }
                        }
                        _activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Snackbar.make(view, "完成\n資產餘額剩餘：" + resBudget, Snackbar.LENGTH_LONG).setAction("Action", null).show();
                                _callCloudListener.onReturn( response.isSuccessful() , this );
                            }
                        });
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            t.start();

            try {
                Thread.sleep(1000);
                t.interrupt();
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //flask願望清單後端儲存
    public void flaskBucketAdd( Calendar calendar , View view , String target , String a , String b , int money , int part )
    {
        try{
            //檢查行事曆
            if (calendar == null)
                calendar = Calendar.getInstance();
            //行事曆物件定義
            int yy = calendar.get(Calendar.YEAR);
            int mon = calendar.get(Calendar.MONTH) + 1;
            int dd = calendar.get(Calendar.DAY_OF_MONTH);
            //資料型態轉換
            String date = String.format("%d/%d/%02d", yy, mon, dd);
            String month = String.format("%d",mon);
            String moneyValue = String.format("%d", money);
            String partValue  = String.format("%d", part);
            //創建OkHttpClient
            OkHttpClient client = new OkHttpClient().newBuilder().connectTimeout(500, TimeUnit.MILLISECONDS).build();
            //放入要POST的參數
            FormBody formBody = new FormBody.Builder()
                    .add("uid", getUID())
                    .add("target", target)
                    .add("date", date)
                    .add("month", month)
                    .add("title", a)
                    .add("detail", b)
                    .add("money", moneyValue)
                    .add("part", partValue)
                    .build();
            //建立request
            Request request = new Request.Builder()
                    .post(formBody)
                    .url(_url + "/bucketAdd")//flask server網址
                    .build();
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    //建立call
                    Call call = client.newCall(request);
                    try {
                        Response response = call.execute();
                        _responseData = response.body().string();
                        _activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Snackbar.make(view, _responseData, Snackbar.LENGTH_LONG).setAction("Action", null).show();
                                _callCloudListener.onReturn( response.isSuccessful() , this );
                            }
                        });
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            t.start();

            try {
                Thread.sleep(1000);
                t.interrupt();
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //flask目標放棄
    public void flaskBucketQuit()
    {
        try {
            //創建OkHttpClient
            OkHttpClient client = new OkHttpClient().newBuilder().connectTimeout(500, TimeUnit.MILLISECONDS).build();
            //放入要POST的參數
            FormBody formBody = new FormBody.Builder()
                    .add("uid", getUID())
                    .build();
            //建立request
            Request request = new Request.Builder()
                    .post(formBody)
                    .url(_url + "/bucketQuit")//flask server網址
                    .build();
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    //建立call
                    Call call = client.newCall(request);
                    try {
                        Response response = call.execute();
                        _activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                _callCloudListener.onReturn( response.isSuccessful() , this );
                            }
                        });
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            t.start();
            try {
                Thread.sleep(1000);
                t.interrupt();
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }catch ( Exception e ){
            e.printStackTrace();
        }
    }

    //flask後端計算刪除帳目後的資產餘額
    public void budgetCalculateAfterRemove( ITEM item )
    {
        //創建OkHttpClient
        OkHttpClient client = new OkHttpClient().newBuilder().connectTimeout(500, TimeUnit.MILLISECONDS).build();
        //放入要POST的參數
        FormBody formBody = new FormBody.Builder()
                .add("uid", getUID())
                .add("money", String.valueOf(item.money))
                .add("title", item.A)
                .build();
        //建立request
        Request request = new Request.Builder()
                .post(formBody)
                .url(_url+"/budgetDel")//flask server網址
                .build();
        //建立call
        Call call = client.newCall(request);
        //執行call連線至flask
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                //連線失敗
//                Snackbar.make( view, "記帳完成\n錯誤：無法更新資產餘額", Snackbar.LENGTH_LONG ).setAction( "Action", null ).show();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                //連線成功
//                Snackbar.make( view, "記帳完成\n資產餘額剩餘：" +  response.body().string(), Snackbar.LENGTH_LONG ).setAction( "Action", null ).show();
            }
        });
    }

    //
    // 新增項目
    public String add( final Activity activity , final Bitmap bmp , Calendar calendar , String a , String b , int money )
    {
        //
        // 加入
        try
        {
            if( calendar == null )
                calendar = Calendar.getInstance();

            _index++;
            int yy = calendar.get( Calendar.YEAR );
            int mon = calendar.get( Calendar.MONTH ) + 1;
            int dd = calendar.get( Calendar.DAY_OF_MONTH );
            int hh = calendar.get( Calendar.HOUR_OF_DAY );
            int mm = calendar.get( Calendar.MINUTE );
            final String ret = String.format( "%04d/%02d/%02d %02d:%02d\t%s\t%s\t%d", yy, mon, dd, hh, mm, a, b, money );
//            final String ret = String.format( "%04d/%02d/%02d\t%s\t%s\t%d", yy, mon, dd, a, b, money );
     //       HashMap<String,Object> map = new HashMap<>();
            ITEM item = new ITEM( "" , ret );
            Map<String,Object> map = item.toJson();

            userCollection().collection( "Account" ).add( map ).addOnCompleteListener( new OnCompleteListener<DocumentReference>()
            {
                @Override
                public void onComplete( @NonNull Task<DocumentReference> task )
                {
                    try
                    {
                        if( task.isSuccessful() )
                        {
                            DocumentReference ref = task.getResult();
                            _items.add( new ITEM( ref.getId(), ret ) );
                            _bmpToFirebase( activity , "add", bmp , ref.getId() );

                        }
                    }catch ( Exception e )
                    {

                    }
                    _callCloudListener.onReturn( task.isSuccessful() , this );
                }
            } );

        }catch ( Exception e )
        {
            e.printStackTrace();
            _callCloudListener.onReturn( false , this );
        }


        return "" ;
    }

    // 移除項目
    public void onDel( ITEM item )
    {
        _listener.MyDataListen_OnDel( item );
    }
    public void delItem( ITEM item )
    {
        int i ;
        final String id = item._firebaseId ;
        for( i = 0 ; i < _items.size() ; ++i )
        {
            if( _items.get( i )._firebaseId.equals(  id ) )
            {

                userCollection().collection( "Account" ).document( id ).delete().addOnCompleteListener( new OnCompleteListener<Void>()
                {
                    @Override
                    public void onComplete( @NonNull Task<Void> task )
                    {
                        if( task.isSuccessful())
                        {
                            int ii ;
                            for( ii = 0 ; ii < _items.size() ; ++ii )
                            {
                                if( _items.get( ii )._firebaseId.equals(  id ) )
                                {
                                    Toast.makeText( _activity, "移除完成：" + item._src, Toast.LENGTH_SHORT ).show();
                                    _items.remove( ii );
                                    break ;
                                }
                            }
                        }
                        _callCloudListener.onReturn( task.isSuccessful() , THIS );
                    }
                } );

                return ;
            }
        }
        _callCloudListener.onReturn( false , "No Data" );
    }



    //
    // TODO: 20220718
    public void onUpdate( ITEM item )
    {
        _listener.MyDataListen_OnUpdate( item );
    }
    // TODO: 20220718 更新
	// 更新firebase item
    public String update( final Activity activity , final Bitmap bmp , Calendar calendar , String a, String b, int money , final String firebaseId )
    {
        try
        {
            if( calendar == null )
                calendar = Calendar.getInstance();

            _index++;
            int yy = calendar.get( Calendar.YEAR );
            int mon = calendar.get( Calendar.MONTH ) + 1;
            int dd = calendar.get( Calendar.DAY_OF_MONTH );
            int hh = calendar.get( Calendar.HOUR_OF_DAY );
            int mm = calendar.get( Calendar.MINUTE );
            final String ret = String.format( "%04d/%02d/%02d %02d:%02d\t%s\t%s\t%d\t%d", yy, mon, dd, hh, mm, a, b, money, _index );
        //    HashMap<String,Object> map = new HashMap<>();
        //    map.put( "data" , ret );
            Map<String,Object> map = new ITEM( "" , ret ).toJson();
            userCollection().collection( "Account" ).document( firebaseId ).update( map ).addOnCompleteListener(new OnCompleteListener< Void >()
            {
                @Override
                public void onComplete( @NonNull @NotNull Task< Void > task )
                {
                    try
                    {
                        if( task.isSuccessful() )
                        {
                            for( ITEM item : _items )
                            {
                                if( item._firebaseId.equals( firebaseId ))
                                {
                                    _items.remove( item );
                                    _items.add( new ITEM( firebaseId , ret ));
                                    break ;
                                }
                            }

                            _bmpToFirebase( activity , "add", bmp , firebaseId );

                        }
                    }catch ( Exception e )
                    {

                    }
                    _callCloudListener.onReturn( task.isSuccessful() , this );

                }
            } );

        }catch ( Exception e )
        {
            e.printStackTrace();
            _callCloudListener.onReturn( false , this );
        }
        return "" ;
    }
    //
    // TODO: 20220729
	// 照相用
    //
    public String getBitmapPath(String id)
    {
        String txt = null;
        try
        {
            if( _user == null )
                return null ;
            _uid = _user.getUid() ;
            txt = "images/"+ _uid + "/" + id + "/" +"imgName";
        }catch( Exception e )
        {
            e.printStackTrace();
            txt = null ;
        }
        return txt;
    }
    // 將照片送上 firebase
    private void _bmpToFirebase( Activity activity , String TAG , Bitmap bmp , String id )
    {
        if( _user == null )
            return ;
        if( bmp == null )
            return ;


        String path = getBitmapPath( id );
        if( path == null )return ;

        final ProgressDialog pDlg = ProgressDialog.show( activity , null , "影像上傳中" , true , false );

        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            // this will compress an image that the uplaod and download would be faster
            bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] data = baos.toByteArray();

            FirebaseStorage storage = FirebaseStorage.getInstance();
            StorageReference storageReference = storage.getReference();
            StorageReference reference = storageReference.child(path);
            UploadTask uploadTask = reference.putBytes(data);

            uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    _listener.MyDataListen_OnMessage( "影像存檔完成" );
                    pDlg.dismiss();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    _listener.MyDataListen_OnMessage( "影像存檔失敗" );
                    pDlg.dismiss();
                }
            });
        }catch (Exception e)
        {
            e.printStackTrace();
            System.out.println( e.getMessage());
            pDlg.dismiss();
        }
    }

    public MyDataListen getListener()
    {
        return _listener ;
    }
}


