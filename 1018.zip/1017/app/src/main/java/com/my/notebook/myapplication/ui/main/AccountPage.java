package com.my.notebook.myapplication.ui.main;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.PieChart;
import com.my.notebook.myapplication.MyData;
import com.my.notebook.myapplication.MyUser;
import com.my.notebook.myapplication.R;

public class AccountPage extends Fragment
        implements FragmentInterface
{
    private final AccountPage THIS= this ;
    private final MyData _data ;

    private PieChart _pieChart;

    private View _root ;


    public AccountPage(MyData data )
    {
        super();
        _data = data ;

    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {

        final View root = _root =inflater.inflate(R.layout.fragment_main_account_page, container, false);

     //   upDate();
        _data.getUserData( this._onFirebaseCallback );

        return root ;

    }

    @Override
    public void upDate()
    {
        TextView tv ;
        if( _data.isLogin())
        {
            _root.findViewById( R.id.layout_login ).setVisibility(View.GONE );
            _root.findViewById( R.id.layout_my_page ).setVisibility(View.VISIBLE );
        }else
        {
            _root.findViewById( R.id.layout_login ).setVisibility(View.VISIBLE );
            _root.findViewById( R.id.layout_my_page ).setVisibility(View.GONE );
        }
        //
        _root.findViewById(R.id.button_sign ).setOnClickListener( _onSignClickListener );
        _root.findViewById(R.id.button_create).setOnClickListener(_onCreateClickListener);
         //
        final MyUser user = _data.getUser();
        setText( R.id.my_username , user.user );
        setText( R.id.my_name , user.name );
        setText( R.id.my_budget , user.budget );
        setText( R.id.my_profession , user.profession );

        // 月報
        final MyData.DATA_YYMMDD yymm = _data.getThisMonth();
        setText( R.id.my_yymm, yymm.toString( user.salary ) );

        // 收入
        setText( R.id.my_salary ,  user.salary );
        // 預算
        tv = _root.findViewById( R.id.my_yymm2 );
        int dd = user.budget - yymm.outMon ;
        tv.setText( "預算-支出=" + dd  );
        tv.setTextColor( Color.BLUE );
        if( dd < 0 )
            tv.setTextColor( Color.RED );

        //    tv.setText(  );
    }
    //
    private void setText( int id , Object text )
    {

        try
        {
            TextView tv;
            tv = _root.findViewById( id );
            tv.setText( text.toString() );
        }catch ( Exception e )
        {

        }

    }

    //

    //
    private final MyData.CallCloudListener _onFirebaseCallback = new MyData.CallCloudListener()
    {

        @Override
        public void onReturn( boolean isOk, Object inData )
        {
            upDate();
        }
    };

    // 登入
    private final View.OnClickListener _onCreateClickListener = new View.OnClickListener()
    {
        @Override
        public void onClick(View v) {
            EditText et ;
            et =  _root.findViewById( R.id.edittext_user );
            String user = et.getText().toString();

            et =  _root.findViewById( R.id.edittext_pass );
            String pass = et.getText().toString();

            _data.createUser( _onFirebaseCallback , user , pass , null );
        }
    };


    // 註冊
    private final View.OnClickListener _onSignClickListener = new View.OnClickListener()
    {
        @Override
        public void onClick(View v)
        {
            EditText et ;
            et =  _root.findViewById( R.id.edittext_user );
            String user = et.getText().toString();

            et =  _root.findViewById( R.id.edittext_pass );
            String pass = et.getText().toString();

            _data.signUser( _onFirebaseCallback , user , pass , null );
        }
    };


    // 登出
    private final View.OnClickListener _onLogoutClickListener = new View.OnClickListener()
    {
        @Override
        public void onClick(View v) {

            _data.logoutUser( _onFirebaseCallback , null );
        }
    };

    private String get( int id , String value )
    {
        try
        {
            TextView tv = _root.findViewById( id );
            return tv.getText().toString();
        }catch ( Exception e )
        {

        }
        return value ;
    }
    private int get( int id , int value )
    {
        try
        {
            TextView tv = _root.findViewById( id );
            return Integer.parseInt( tv.getText().toString() );
        }catch ( Exception e )
        {

        }
        return value ;
    }
    // 更新
    private final View.OnClickListener _onUpdateClickListener = new View.OnClickListener()
    {
        @Override
        public void onClick(View v) {

            MyUser user = _data.getUser();
            user.name = get( R.id.my_name , user.name );
            user.budget = get( R.id.my_budget , user.budget );
            user.salary = get( R.id.my_salary , user.salary );
            user.profession = get( R.id.my_profession , user.profession );
            _data.setUser( _onFirebaseCallback , user );
        }
    };


}
